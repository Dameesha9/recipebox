// Recipe model
const fs = require("fs")
const path = require("path")

const dataPath = path.join(__dirname, "..", "data", "recipes.json")

// Ensure data directory exists
const dataDir = path.join(__dirname, "..", "data")
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir)
}

// Initialize recipes file if it doesn't exist
if (!fs.existsSync(dataPath)) {
  fs.writeFileSync(dataPath, JSON.stringify([]))
}

class Recipe {
  static async getAll() {
    try {
      const data = fs.readFileSync(dataPath, "utf8")
      return JSON.parse(data)
    } catch (error) {
      console.error("Error reading recipes:", error)
      return []
    }
  }

  static async getById(id) {
    const recipes = await this.getAll()
    return recipes.find((recipe) => recipe.id === id)
  }

  static async getByUser(userId) {
    const recipes = await this.getAll()
    return recipes.filter((recipe) => recipe.createdBy === userId)
  }

  static async create(recipeData) {
    try {
      const recipes = await this.getAll()

      const newRecipe = {
        id: Date.now().toString(),
        ...recipeData,
        createdAt: new Date().toISOString(),
      }

      recipes.push(newRecipe)
      fs.writeFileSync(dataPath, JSON.stringify(recipes, null, 2))

      return newRecipe
    } catch (error) {
      console.error("Error creating recipe:", error)
      throw error
    }
  }

  static async update(id, recipeData) {
    try {
      const recipes = await this.getAll()
      const index = recipes.findIndex((recipe) => recipe.id === id)

      if (index === -1) {
        throw new Error("Recipe not found")
      }

      // Update recipe data
      recipes[index] = { ...recipes[index], ...recipeData }

      fs.writeFileSync(dataPath, JSON.stringify(recipes, null, 2))
      return recipes[index]
    } catch (error) {
      console.error("Error updating recipe:", error)
      throw error
    }
  }

  static async delete(id) {
    try {
      const recipes = await this.getAll()
      const filteredRecipes = recipes.filter((recipe) => recipe.id !== id)

      fs.writeFileSync(dataPath, JSON.stringify(filteredRecipes, null, 2))
      return true
    } catch (error) {
      console.error("Error deleting recipe:", error)
      throw error
    }
  }

  static async search(query, tags = []) {
    try {
      const recipes = await this.getAll()

      return recipes.filter((recipe) => {
        // Search by query
        const matchesQuery =
          !query ||
          recipe.title.toLowerCase().includes(query.toLowerCase()) ||
          recipe.description.toLowerCase().includes(query.toLowerCase())

        // Filter by tags
        const matchesTags = tags.length === 0 || tags.some((tag) => recipe.tags.includes(tag))

        return matchesQuery && matchesTags
      })
    } catch (error) {
      console.error("Error searching recipes:", error)
      throw error
    }
  }
}

module.exports = Recipe
