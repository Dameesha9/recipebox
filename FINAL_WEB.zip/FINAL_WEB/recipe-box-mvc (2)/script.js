// Data Storage
const localStorageKeys = {
  USERS: "recipeBox_users",
  CURRENT_USER: "recipeBox_currentUser",
  RECIPES: "recipeBox_recipes",
  SAVED_RECIPES: "recipeBox_savedRecipes",
}

// Initial data
const initialUsers = [
  {
    id: "1",
    name: "John Doe",
    email: "john@example.com",
    password: "Password123!", // In a real app, this would be hashed
  },
]

const initialRecipes = [
  {
    id: "1",
    title: "Classic Pancakes",
    description: "Light and fluffy pancakes perfect for breakfast",
    ingredients: [
      "1 1/2 cups all-purpose flour",
      "3 1/2 teaspoons baking powder",
      "1 teaspoon salt",
      "1 tablespoon white sugar",
      "1 1/4 cups milk",
      "1 egg",
      "3 tablespoons butter, melted",
    ],
    instructions: [
      "In a large bowl, sift together the flour, baking powder, salt and sugar.",
      "Make a well in the center and pour in the milk, egg and melted butter; mix until smooth.",
      "Heat a lightly oiled griddle or frying pan over medium-high heat.",
      "Pour or scoop the batter onto the griddle, using approximately 1/4 cup for each pancake.",
      "Brown on both sides and serve hot.",
    ],
    prepTime: 10,
    cookTime: 15,
    servings: 4,
    imageUrl: "https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?ixlib=rb-4.0.3",
    tags: ["breakfast", "vegetarian", "quick"],
    createdAt: "2023-01-01T08:00:00Z",
    createdBy: "1",
  },
  {
    id: "2",
    title: "Vegetable Stir Fry",
    description: "A quick and healthy vegetable stir fry",
    ingredients: [
      "2 tablespoons vegetable oil",
      "1 onion, sliced",
      "2 bell peppers, sliced",
      "2 carrots, julienned",
      "1 cup broccoli florets",
      "3 cloves garlic, minced",
      "2 tablespoons soy sauce",
      "1 tablespoon honey",
    ],
    instructions: [
      "Heat oil in a large wok or skillet over medium-high heat.",
      "Add onions and stir fry for 2 minutes until translucent.",
      "Add the remaining vegetables and stir fry for 5-6 minutes until crisp-tender.",
      "Add garlic and cook for 30 seconds until fragrant.",
      "Mix soy sauce and honey in a small bowl, then pour over vegetables.",
      "Stir to coat and cook for another minute. Serve immediately.",
    ],
    prepTime: 15,
    cookTime: 10,
    servings: 4,
    imageUrl: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?ixlib=rb-4.0.3",
    tags: ["dinner", "vegetarian", "healthy", "quick"],
    createdAt: "2023-01-02T18:30:00Z",
    createdBy: "1",
  },
  {
    id: "3",
    title: "Chocolate Chip Cookies",
    description: "Classic chewy chocolate chip cookies with crisp edges",
    ingredients: [
      "1 cup butter, softened",
      "1 cup white sugar",
      "1 cup packed brown sugar",
      "2 eggs",
      "2 teaspoons vanilla extract",
      "3 cups all-purpose flour",
      "1 teaspoon baking soda",
      "2 teaspoons hot water",
      "1/2 teaspoon salt",
      "2 cups semisweet chocolate chips",
    ],
    instructions: [
      "Preheat oven to 350°F (175°C).",
      "Cream together the butter, white sugar, and brown sugar until smooth.",
      "Beat in the eggs one at a time, then stir in the vanilla.",
      "Dissolve baking soda in hot water. Add to batter along with salt.",
      "Stir in flour and chocolate chips.",
      "Drop by large spoonfuls onto ungreased pans.",
      "Bake for about 10 minutes or until edges are nicely browned.",
    ],
    prepTime: 20,
    cookTime: 10,
    servings: 24,
    imageUrl: "https://images.unsplash.com/photo-1499636136210-6f4ee915583e?ixlib=rb-4.0.3",
    tags: ["dessert", "baking", "cookies", "kids-friendly"],
    createdAt: "2023-01-03T14:20:00Z",
    createdBy: "1",
  },
  {
    id: "4",
    title: "Classic Caesar Salad",
    description: "Fresh and crisp Caesar salad with homemade dressing",
    ingredients: [
      "1 head romaine lettuce",
      "1/4 cup olive oil",
      "3 tablespoons lemon juice",
      "2 cloves garlic, minced",
      "1 teaspoon Worcestershire sauce",
      "1 teaspoon Dijon mustard",
      "1/4 cup grated Parmesan cheese",
      "1/2 cup croutons",
      "Salt and black pepper to taste",
    ],
    instructions: [
      "Wash and dry the lettuce, then tear into bite-size pieces.",
      "In a small bowl, whisk together the olive oil, lemon juice, garlic, Worcestershire sauce, and Dijon mustard.",
      "Place lettuce in a large bowl, pour dressing over top and toss well to coat.",
      "Sprinkle with Parmesan cheese, croutons, salt, and pepper.",
      "Toss again and serve immediately.",
    ],
    prepTime: 15,
    cookTime: 0,
    servings: 4,
    imageUrl: "https://images.unsplash.com/photo-1599021456807-25db0f974333?ixlib=rb-4.0.3",
    tags: ["salad", "quick", "no-cook", "lunch"],
    createdAt: "2023-01-04T12:15:00Z",
    createdBy: "1",
  },
  {
    id: "5",
    title: "Beef Tacos",
    description: "Simple and delicious beef tacos with fresh toppings",
    ingredients: [
      "1 pound ground beef",
      "1 packet taco seasoning",
      "8 taco shells",
      "1 cup shredded lettuce",
      "1 cup diced tomatoes",
      "1/2 cup shredded cheddar cheese",
      "1/4 cup diced onions",
      "1/2 cup sour cream",
      "Hot sauce to taste",
    ],
    instructions: [
      "In a skillet, brown the ground beef over medium-high heat until no longer pink.",
      "Drain excess fat, then add taco seasoning and water according to package directions.",
      "Simmer until water is absorbed, about 5 minutes.",
      "Heat taco shells according to package directions.",
      "Fill shells with beef mixture and top with lettuce, tomatoes, cheese, onions, sour cream, and hot sauce as desired.",
    ],
    prepTime: 10,
    cookTime: 15,
    servings: 4,
    imageUrl: "https://images.unsplash.com/photo-1574782151627-0c8fc554dea1?ixlib=rb-4.0.3",
    tags: ["dinner", "mexican", "quick", "family-friendly"],
    createdAt: "2023-01-05T18:40:00Z",
    createdBy: "1",
  },
  {
    id: "6",
    title: "Creamy Mushroom Pasta",
    description: "Delicious pasta with a rich and creamy mushroom sauce",
    ingredients: [
      "8 oz fettuccine pasta",
      "2 tablespoons olive oil",
      "1 pound mushrooms, sliced",
      "3 cloves garlic, minced",
      "1 cup heavy cream",
      "1/2 cup grated Parmesan cheese",
      "2 tablespoons fresh parsley, chopped",
      "Salt and pepper to taste",
    ],
    instructions: [
      "Cook pasta according to package directions. Reserve 1/2 cup pasta water before draining.",
      "While pasta cooks, heat olive oil in a large skillet over medium-high heat.",
      "Add mushrooms and cook until golden, about 5-7 minutes.",
      "Add garlic and cook until fragrant, about 1 minute.",
      "Reduce heat to medium and add heavy cream, stirring occasionally until slightly thickened.",
      "Add drained pasta, Parmesan cheese, and toss to coat. Add pasta water as needed if sauce is too thick.",
      "Season with salt and pepper, and garnish with parsley before serving.",
    ],
    prepTime: 10,
    cookTime: 20,
    servings: 4,
    imageUrl: "https://images.unsplash.com/photo-1603729362753-f8162ac6c3df?ixlib=rb-4.0.3",
    tags: ["pasta", "dinner", "vegetarian", "comfort food"],
    createdAt: "2023-01-06T19:15:00Z",
    createdBy: "1",
  },
]

// Initialize data in local storage
function initializeLocalStorage() {
  if (!localStorage.getItem(localStorageKeys.USERS)) {
    localStorage.setItem(localStorageKeys.USERS, JSON.stringify(initialUsers))
  }
  if (!localStorage.getItem(localStorageKeys.RECIPES)) {
    localStorage.setItem(localStorageKeys.RECIPES, JSON.stringify(initialRecipes))
  }
}

// Data Access Functions
function getUsers() {
  return JSON.parse(localStorage.getItem(localStorageKeys.USERS) || "[]")
}

function getRecipes() {
  return JSON.parse(localStorage.getItem(localStorageKeys.RECIPES) || "[]")
}

function getCurrentUser() {
  return JSON.parse(localStorage.getItem(localStorageKeys.CURRENT_USER) || "null")
}

function getSavedRecipes() {
  const currentUser = getCurrentUser()
  if (!currentUser) return []

  const savedIds = JSON.parse(localStorage.getItem(`${localStorageKeys.SAVED_RECIPES}_${currentUser.id}`) || "[]")
  const recipes = getRecipes()
  return recipes.filter((recipe) => savedIds.includes(recipe.id))
}

function saveUser(user) {
  const users = getUsers()
  const existingUserIndex = users.findIndex((u) => u.id === user.id)

  if (existingUserIndex >= 0) {
    users[existingUserIndex] = user
  } else {
    users.push(user)
  }

  localStorage.setItem(localStorageKeys.USERS, JSON.stringify(users))
}

function saveRecipe(recipe) {
  const recipes = getRecipes()
  const existingRecipeIndex = recipes.findIndex((r) => r.id === recipe.id)

  if (existingRecipeIndex >= 0) {
    recipes[existingRecipeIndex] = recipe
  } else {
    recipe.id = Date.now().toString()
    recipe.createdAt = new Date().toISOString()
    const currentUser = getCurrentUser()
    recipe.createdBy = currentUser ? currentUser.id : "anonymous"
    recipes.push(recipe)
  }

  localStorage.setItem(localStorageKeys.RECIPES, JSON.stringify(recipes))
  return recipe
}

function deleteRecipe(recipeId) {
  const recipes = getRecipes()
  const updatedRecipes = recipes.filter((recipe) => recipe.id !== recipeId)
  localStorage.setItem(localStorageKeys.RECIPES, JSON.stringify(updatedRecipes))

  // Remove from saved recipes as well
  const currentUser = getCurrentUser()
  if (currentUser) {
    const savedIds = JSON.parse(localStorage.getItem(`${localStorageKeys.SAVED_RECIPES}_${currentUser.id}`) || "[]")
    const updatedSavedIds = savedIds.filter((id) => id !== recipeId)
    localStorage.setItem(`${localStorageKeys.SAVED_RECIPES}_${currentUser.id}`, JSON.stringify(updatedSavedIds))
  }
}

function saveRecipeToCollection(recipeId) {
  const currentUser = getCurrentUser()
  if (!currentUser) return false

  const savedIdsKey = `${localStorageKeys.SAVED_RECIPES}_${currentUser.id}`
  const savedIds = JSON.parse(localStorage.getItem(savedIdsKey) || "[]")
  if (!savedIds.includes(recipeId)) {
    savedIds.push(recipeId)
    localStorage.setItem(savedIdsKey, JSON.stringify(savedIds))

    // Send notification email to recipe creator (if it's not the current user)
    const recipes = getRecipes()
    const recipe = recipes.find((r) => r.id === recipeId)
    if (recipe && recipe.createdBy !== currentUser.id) {
      const users = getUsers()
      const creator = users.find((u) => u.id === recipe.createdBy)
      if (creator && window.emailService) {
        window.emailService
          .sendRecipeSavedEmail(creator.email, creator.name, recipe.title, currentUser.name)
          .then(() => console.log("Recipe saved notification sent"))
          .catch((error) => console.error("Error sending recipe saved notification:", error))
      }
    }

    return true
  }
  return false
}

function removeRecipeFromCollection(recipeId) {
  const currentUser = getCurrentUser()
  if (!currentUser) return false

  const savedIdsKey = `${localStorageKeys.SAVED_RECIPES}_${currentUser.id}`
  const savedIds = JSON.parse(localStorage.getItem(savedIdsKey) || "[]")
  const updatedIds = savedIds.filter((id) => id !== recipeId)
  localStorage.setItem(savedIdsKey, JSON.stringify(updatedIds))
  return true
}

function isRecipeSaved(recipeId) {
  const currentUser = getCurrentUser()
  if (!currentUser) return false

  const savedIdsKey = `${localStorageKeys.SAVED_RECIPES}_${currentUser.id}`
  const savedIds = JSON.parse(localStorage.getItem(savedIdsKey) || "[]")
  return savedIds.includes(recipeId)
}

function getSharedRecipes() {
  const currentUser = getCurrentUser()
  if (!currentUser) return []

  const sharedRecipesKey = `recipeBox_sharedRecipes_${currentUser.id}`
  return JSON.parse(localStorage.getItem(sharedRecipesKey) || "[]")
}

function isRecipeShared(recipeId) {
  const sharedRecipes = getSharedRecipes()
  return sharedRecipes.some((share) => share.recipeId === recipeId)
}

function getRecipeShareCount(recipeId) {
  const sharedRecipes = getSharedRecipes()
  return sharedRecipes.filter((share) => share.recipeId === recipeId).length
}

// Authentication Functions
function register(name, email, password) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const users = getUsers()
      const existingUser = users.find((user) => user.email === email)

      if (existingUser) {
        reject(new Error("Email already in use"))
        return
      }

      if (!validatePassword(password)) {
        reject(new Error("Password must be at least 8 characters with at least one special character"))
        return
      }

      const newUser = {
        id: Date.now().toString(),
        name,
        email,
        password,
      }

      saveUser(newUser)

      // Don't return the password
      const { password: _, ...userWithoutPassword } = newUser
      localStorage.setItem(localStorageKeys.CURRENT_USER, JSON.stringify(userWithoutPassword))

      // Send welcome email
      if (window.emailService) {
        window.emailService
          .sendWelcomeEmail(email, name)
          .then(() => console.log("Welcome email sent"))
          .catch((error) => console.error("Error sending welcome email:", error))
      }

      resolve(userWithoutPassword)
    }, 500)
  })
}

function login(email, password) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const users = getUsers()
      const user = users.find((user) => user.email === email && user.password === password)

      if (!user) {
        reject(new Error("Invalid email or password"))
        return
      }

      // Don't return the password
      const { password: _, ...userWithoutPassword } = user
      localStorage.setItem(localStorageKeys.CURRENT_USER, JSON.stringify(userWithoutPassword))

      resolve(userWithoutPassword)
    }, 500)
  })
}

function logout() {
  localStorage.removeItem(localStorageKeys.CURRENT_USER)
}

function resetPassword(email) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const users = getUsers()
      const user = users.find((user) => user.email === email)

      if (!user) {
        // Don't reveal that the user doesn't exist
        resolve(true)
        return
      }

      // In a real app, we would send an email with a reset link
      if (window.emailService) {
        window.emailService
          .sendPasswordResetEmail(email, user.name)
          .then(() => resolve(true))
          .catch((error) => reject(error))
      } else {
        resolve(true)
      }
    }, 500)
  })
}

function validatePassword(password) {
  // At least 8 characters with at least one special character
  const specialChars = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]+/
  return password.length >= 8 && specialChars.test(password)
}

// UI Functions
function showToast(message, type = "info") {
  const toastContainer = document.getElementById("toast-container")
  const toast = document.createElement("div")
  toast.className = `toast toast-${type}`
  toast.innerHTML = `
    <span>${message}</span>
    <button class="toast-close">×</button>
  `

  toastContainer.appendChild(toast)

  // Auto-remove toast after 5 seconds
  setTimeout(() => {
    closeToast(toast)
  }, 5000)

  // Add event listener to close button
  toast.querySelector(".toast-close").addEventListener("click", () => {
    closeToast(toast)
  })
}

function closeToast(toast) {
  toast.style.animation = "slideOut 0.3s ease forwards"
  setTimeout(() => {
    toast.remove()
  }, 300)
}

function showLoading() {
  const loadingOverlay = document.getElementById("loading-overlay")
  loadingOverlay.classList.add("visible")
}

function hideLoading() {
  const loadingOverlay = document.getElementById("loading-overlay")
  loadingOverlay.classList.remove("visible")
}

// Router Functions
const routes = {
  "/": renderHome,
  "/login": renderLogin,
  "/register": renderRegister,
  "/forgot-password": renderForgotPassword,
  "/recipes": renderRecipeList,
  "/recipes/new": renderCreateRecipe,
  "/recipes/edit": renderEditRecipe,
  "/recipes/view": renderRecipeDetail,
  "/recipes/share": renderShareRecipe,
  "/saved-recipes": renderSavedRecipes,
}

function navigateTo(path, params = {}) {
  // Set URL parameters if provided
  let url = path
  const searchParams = new URLSearchParams()

  for (const [key, value] of Object.entries(params)) {
    searchParams.set(key, value)
  }

  const searchParamsString = searchParams.toString()
  if (searchParamsString) {
    url = `${url}?${searchParamsString}`
  }

  window.history.pushState({ path: url }, "", url)
  handleRouteChange()
}

function getUrlParams() {
  const searchParams = new URLSearchParams(window.location.search)
  const params = {}

  for (const [key, value] of searchParams.entries()) {
    params[key] = value
  }

  return params
}

function handleRouteChange() {
  const path = window.location.pathname || "/"
  const renderFunction = routes[path] || renderNotFound

  const mainContent = document.getElementById("main-content")
  mainContent.innerHTML = ""

  renderFunction()
  updateNav()
}

function getTemplate(id) {
  const template = document.getElementById(id)
  if (!template) {
    console.error(`Template not found: ${id}`)
    return null
  }
  return document.importNode(template.content, true)
}

// Page Rendering Functions
function renderHome() {
  const template = getTemplate("home-template")
  const mainContent = document.getElementById("main-content")
  mainContent.appendChild(template)

  // Add event listeners
  document.getElementById("login-btn").addEventListener("click", () => {
    navigateTo("/login")
  })

  document.getElementById("browse-recipes-btn").addEventListener("click", () => {
    // Check if user is logged in before navigating to recipes
    if (getCurrentUser()) {
      navigateTo("/recipes")
    } else {
      navigateTo("/login")
      showToast("Please log in to view recipes", "info")
    }
  })

  const signupBtn = document.getElementById("signup-btn")
  if (signupBtn) {
    signupBtn.addEventListener("click", () => {
      navigateTo("/register")
    })
  }
}

function renderLogin() {
  const template = getTemplate("login-template")
  const mainContent = document.getElementById("main-content")
  mainContent.appendChild(template)

  // Add event listeners
  document.getElementById("login-form").addEventListener("submit", handleLogin)
  document.getElementById("forgot-password-link").addEventListener("click", (e) => {
    e.preventDefault()
    navigateTo("/forgot-password")
  })
  document.getElementById("register-link").addEventListener("click", (e) => {
    e.preventDefault()
    navigateTo("/register")
  })
}

function renderRegister() {
  const template = getTemplate("register-template")
  const mainContent = document.getElementById("main-content")
  mainContent.appendChild(template)

  // Add event listeners
  document.getElementById("register-form").addEventListener("submit", handleRegister)
  document.getElementById("login-link").addEventListener("click", (e) => {
    e.preventDefault()
    navigateTo("/login")
  })
}

function renderForgotPassword() {
  const template = getTemplate("forgot-password-template")
  const mainContent = document.getElementById("main-content")
  mainContent.appendChild(template)

  // Add event listeners
  document.getElementById("forgot-password-form").addEventListener("submit", handleForgotPassword)
  document.getElementById("back-to-login").addEventListener("click", (e) => {
    e.preventDefault()
    navigateTo("/login")
  })
}

function renderRecipeList() {
  // Redirect if not logged in
  if (!checkAuth()) return

  const template = getTemplate("recipe-list-template")
  const mainContent = document.getElementById("main-content")
  mainContent.appendChild(template)

  // Add event listeners
  document.getElementById("search-button").addEventListener("click", handleRecipeSearch)
  document.getElementById("search-input").addEventListener("keypress", (e) => {
    if (e.key === "Enter") {
      handleRecipeSearch()
    }
  })

  document.getElementById("add-recipe-btn").addEventListener("click", () => {
    navigateTo("/recipes/new")
  })

  // Display recipes
  displayRecipes(getRecipes())

  // Setup filters
  setupFilters()
}

function renderSavedRecipes() {
  // Redirect if not logged in
  if (!checkAuth()) return

  const template = getTemplate("saved-recipes-template")
  const mainContent = document.getElementById("main-content")
  mainContent.appendChild(template)

  // Get saved recipes
  const savedRecipes = getSavedRecipes()

  // Show empty state or recipes
  const recipeListContainer = document.getElementById("saved-recipe-list")
  const emptyStateContainer = document.getElementById("empty-saved-recipes")

  if (savedRecipes.length === 0) {
    recipeListContainer.classList.add("hidden")
    emptyStateContainer.classList.remove("hidden")
    document.getElementById("browse-from-empty").addEventListener("click", () => {
      navigateTo("/recipes")
    })
  } else {
    recipeListContainer.classList.remove("hidden")
    emptyStateContainer.classList.add("hidden")
    savedRecipes.forEach((recipe) => {
      recipeListContainer.appendChild(createRecipeCard(recipe, true))
    })
  }
}

function renderCreateRecipe() {
  // Redirect if not logged in
  if (!checkAuth()) return

  const template = getTemplate("recipe-form-template")
  const mainContent = document.getElementById("main-content")
  mainContent.appendChild(template)

  // Set form for create mode
  document.getElementById("form-title").textContent = "Add Recipe"
  document.getElementById("form-description").textContent = "Share your culinary creation with the world"
  document.getElementById("save-recipe-form-btn").textContent = "Create Recipe"

  // Add event listeners
  setupRecipeForm()

  document.getElementById("recipe-form").addEventListener("submit", handleCreateRecipe)
  document.getElementById("cancel-recipe-btn").addEventListener("click", () => {
    navigateTo("/recipes")
  })
}

function renderEditRecipe() {
  // Redirect if not logged in
  if (!checkAuth()) return

  const params = getUrlParams()
  const recipeId = params.id

  if (!recipeId) {
    navigateTo("/recipes")
    return
  }

  const recipe = getRecipes().find((r) => r.id === recipeId)

  if (!recipe) {
    navigateTo("/recipes")
    return
  }

  const template = getTemplate("recipe-form-template")
  const mainContent = document.getElementById("main-content")
  mainContent.appendChild(template)

  // Set form for edit mode
  document.getElementById("form-title").textContent = "Edit Recipe"
  document.getElementById("form-description").textContent = "Update your recipe"
  document.getElementById("save-recipe-form-btn").textContent = "Update Recipe"

  // Fill form with recipe data
  document.getElementById("recipe-title").value = recipe.title
  document.getElementById("recipe-description").value = recipe.description
  document.getElementById("recipe-prep-time").value = recipe.prepTime
  document.getElementById("recipe-cook-time").value = recipe.cookTime
  document.getElementById("recipe-servings").value = recipe.servings
  document.getElementById("recipe-image-url").value = recipe.imageUrl || ""
  document.getElementById("recipe-tags").value = recipe.tags.join(", ")

  // Add ingredients
  const ingredientsContainer = document.getElementById("ingredients-container")
  ingredientsContainer.innerHTML = ""

  recipe.ingredients.forEach((ingredient) => {
    const row = createIngredientRow(ingredient)
    ingredientsContainer.appendChild(row)
  })

  // Add instructions
  const instructionsContainer = document.getElementById("instructions-container")
  instructionsContainer.innerHTML = ""

  recipe.instructions.forEach((instruction, index) => {
    const row = createInstructionRow(instruction, index + 1)
    instructionsContainer.appendChild(row)
  })

  // Add event listeners
  setupRecipeForm()

  document.getElementById("recipe-form").addEventListener("submit", (e) => {
    e.preventDefault()
    handleEditRecipe(recipeId)
  })

  document.getElementById("cancel-recipe-btn").addEventListener("click", () => {
    navigateTo("/recipes")
  })
}

function renderRecipeDetail() {
  // Redirect if not logged in
  if (!checkAuth()) return

  const params = getUrlParams()
  const recipeId = params.id

  if (!recipeId) {
    navigateTo("/recipes")
    return
  }

  const recipe = getRecipes().find((r) => r.id === recipeId)

  if (!recipe) {
    navigateTo("/recipes")
    return
  }

  const template = getTemplate("recipe-detail-template")
  const mainContent = document.getElementById("main-content")
  mainContent.appendChild(template)

  // Fill template with recipe data
  document.getElementById("detail-title").textContent = recipe.title
  document.getElementById("detail-description").textContent = recipe.description
  document.getElementById("detail-prep-time").textContent = `Prep: ${recipe.prepTime} min`
  document.getElementById("detail-cook-time").textContent = `Cook: ${recipe.cookTime} min`
  document.getElementById("detail-servings").textContent = `Serves: ${recipe.servings}`

  const imageElement = document.getElementById("detail-image")
  imageElement.src = recipe.imageUrl || "https://via.placeholder.com/800x500?text=No+Image"
  imageElement.alt = recipe.title

  // Add tags
  const tagsContainer = document.getElementById("detail-tags")
  recipe.tags.forEach((tag) => {
    const tagElement = document.createElement("span")
    tagElement.className = "recipe-tag"
    tagElement.textContent = tag
    tagsContainer.appendChild(tagElement)
  })

  // Add ingredients
  const ingredientsList = document.getElementById("detail-ingredients")
  recipe.ingredients.forEach((ingredient) => {
    const li = document.createElement("li")
    li.textContent = ingredient
    ingredientsList.appendChild(li)
  })

  // Add instructions
  const instructionsList = document.getElementById("detail-instructions")
  recipe.instructions.forEach((instruction) => {
    const li = document.createElement("li")
    li.textContent = instruction
    instructionsList.appendChild(li)
  })

  // Setup action buttons
  const saveButton = document.getElementById("save-recipe-btn")
  const editButton = document.getElementById("edit-recipe-btn")
  const deleteButton = document.getElementById("delete-recipe-btn")
  const shareButton = document.getElementById("share-recipe-btn")

  const currentUser = getCurrentUser()
  const isOwner = currentUser && recipe.createdBy === currentUser.id
  const isSaved = isRecipeSaved(recipe.id)
  const isShared = isRecipeShared(recipe.id)
  const shareCount = getRecipeShareCount(recipe.id)

  // Show/hide edit and delete buttons based on ownership
  if (!isOwner) {
    editButton.classList.add("hidden")
    deleteButton.classList.add("hidden")
  }

  // Update save button text
  saveButton.textContent = isSaved ? "Unsave Recipe" : "Save Recipe"

  // Add event listeners
  saveButton.addEventListener("click", () => {
    if (isSaved) {
      removeRecipeFromCollection(recipe.id)
      saveButton.textContent = "Save Recipe"
      showToast("Recipe removed from your collection", "success")
    } else {
      saveRecipeToCollection(recipe.id)
      saveButton.textContent = "Unsave Recipe"
      showToast("Recipe saved to your collection", "success")
    }
  })

  editButton.addEventListener("click", () => {
    navigateTo("/recipes/edit", { id: recipe.id })
  })

  deleteButton.addEventListener("click", () => {
    if (confirm("Are you sure you want to delete this recipe?")) {
      deleteRecipe(recipe.id)
      showToast("Recipe deleted successfully", "success")
      navigateTo("/recipes")
    }
  })

  shareButton.addEventListener("click", () => {
    navigateTo("/recipes/share", { id: recipe.id })
  })

  if (isShared) {
    const shareInfo = document.createElement("div")
    shareInfo.className = "share-info"
    shareInfo.innerHTML = `<span>Shared ${shareCount} time${shareCount !== 1 ? "s" : ""}</span>`
    document.querySelector(".recipe-actions").appendChild(shareInfo)
  }
}

function renderShareRecipe() {
  // Redirect if not logged in
  if (!checkAuth()) return

  const params = getUrlParams()
  const recipeId = params.id

  if (!recipeId) {
    navigateTo("/recipes")
    return
  }

  const recipe = getRecipes().find((r) => r.id === recipeId)

  if (!recipe) {
    navigateTo("/recipes")
    return
  }

  const template = getTemplate("share-recipe-template")
  const mainContent = document.getElementById("main-content")
  mainContent.appendChild(template)

  // Add event listeners
  document.getElementById("share-recipe-form").addEventListener("submit", (e) => {
    e.preventDefault()

    const recipientEmail = document.getElementById("recipient-email").value
    const message = document.getElementById("share-message").value

    // Get current user
    const currentUser = getCurrentUser()

    // Create a shareable URL (in a real app, this would be a proper URL)
    const recipeUrl = `${window.location.origin}${window.location.pathname}?view=recipes&id=${recipeId}`

    showLoading()

    // Send the email
    if (window.emailService) {
      window.emailService
        .shareRecipeWithFriend(recipientEmail, currentUser.name, recipe.title, recipeUrl, message)
        .then(() => {
          showToast("Recipe shared successfully!", "success")
          navigateTo("/recipes/view", { id: recipeId })
        })
        .catch((error) => {
          showToast(error.message, "error")
        })
        .finally(() => {
          hideLoading()
        })
    } else {
      // Fallback if email service is not available
      setTimeout(() => {
        showToast("Recipe shared successfully!", "success")
        navigateTo("/recipes/view", { id: recipeId })
        hideLoading()
      }, 1000)
    }
  })

  document.getElementById("back-to-recipe").addEventListener("click", (e) => {
    e.preventDefault()
    navigateTo("/recipes/view", { id: recipeId })
  })
}

function renderNotFound() {
  const template = getTemplate("not-found-template")
  const mainContent = document.getElementById("main-content")
  mainContent.appendChild(template)

  document.getElementById("go-home-btn").addEventListener("click", () => {
    navigateTo("/")
  })
}

// Helper UI Functions
function updateNav() {
  const nav = document.getElementById("main-nav")
  const currentUser = getCurrentUser()

  nav.innerHTML = `
    <ul>
      <li><a href="#" class="nav-link" data-route="/">Home</a></li>
      ${
        currentUser
          ? `
        <li><a href="#" class="nav-link" data-route="/recipes">Recipes</a></li>
        <li><a href="#" class="nav-link" data-route="/saved-recipes">My Collection</a></li>
        <li><a href="#" class="nav-link" data-route="/recipes/new">Add Recipe</a></li>
        <li><button class="nav-button" id="logout-btn">Logout (${currentUser.name})</button></li>
      `
          : `
        <li><a href="#" class="nav-link" data-route="/login">Login</a></li>
        <li><a href="#" class="nav-link" data-route="/register">Register</a></li>
      `
      }
    </ul>
  `

  // Add event listeners to nav links
  const navLinks = document.querySelectorAll(".nav-link")
  navLinks.forEach((link) => {
    link.addEventListener("click", (e) => {
      e.preventDefault()
      navigateTo(link.getAttribute("data-route"))
    })

    // Add active class to current route
    if (link.getAttribute("data-route") === window.location.pathname) {
      link.classList.add("active")
    }
  })

  // Add event listener to logout button
  const logoutBtn = document.getElementById("logout-btn")
  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      logout()
      showToast("You have been logged out", "success")
      navigateTo("/")
    })
  }
}

function displayRecipes(recipes) {
  const recipeList = document.getElementById("recipe-list")
  recipeList.innerHTML = ""

  if (recipes.length === 0) {
    recipeList.innerHTML = `
      <div class="empty-state">
        <p>No recipes match your search. Try adjusting your filters.</p>
      </div>
    `
    return
  }

  recipes.forEach((recipe) => {
    recipeList.appendChild(createRecipeCard(recipe))
  })
}

function createRecipeCard(recipe, isSaved = false) {
  const card = document.createElement("div")
  card.className = "recipe-card"

  card.innerHTML = `
    <div class="recipe-card-image">
      <img src="${recipe.imageUrl || "https://via.placeholder.com/400x300?text=No+Image"}" alt="${recipe.title}">
    </div>
    <div class="recipe-card-content">
      <h3 class="recipe-card-title">${recipe.title}</h3>
      <p class="recipe-card-description">${recipe.description}</p>
      <div class="recipe-card-meta">
        <span>Prep: ${recipe.prepTime} min</span>
        <span>Cook: ${recipe.cookTime} min</span>
      </div>
      <div class="recipe-card-tags">
        ${recipe.tags.map((tag) => `<span class="recipe-tag">${tag}</span>`).join("")}
      </div>
      <div class="recipe-card-actions">
        <button class="btn btn-primary view-recipe" data-id="${recipe.id}">View Recipe</button>
        <button class="btn btn-outline toggle-save" data-id="${recipe.id}">
          ${isRecipeSaved(recipe.id) || isSaved ? "Unsave" : "Save"}
        </button>
      </div>
    </div>
  `

  // Add event listeners
  card.querySelector(".view-recipe").addEventListener("click", () => {
    navigateTo("/recipes/view", { id: recipe.id })
  })

  const saveButton = card.querySelector(".toggle-save")
  if (saveButton) {
    saveButton.addEventListener("click", () => {
      const recipeId = saveButton.getAttribute("data-id")
      const isSaved = isRecipeSaved(recipeId)

      if (isSaved) {
        removeRecipeFromCollection(recipeId)
        saveButton.textContent = "Save"
        showToast("Recipe removed from your collection", "success")

        // If we're on the saved recipes page, remove the card
        if (window.location.pathname === "/saved-recipes") {
          card.remove()

          // Check if we need to show the empty state
          const savedRecipesList = document.getElementById("saved-recipe-list")
          if (savedRecipesList && savedRecipesList.children.length === 0) {
            savedRecipesList.classList.add("hidden")
            document.getElementById("empty-saved-recipes").classList.remove("hidden")
          }
        }
      } else {
        saveRecipeToCollection(recipeId)
        saveButton.textContent = "Unsave"
        showToast("Recipe saved to your collection", "success")
      }
    })
  }

  return card
}

function createIngredientRow(value = "") {
  const row = document.createElement("div")
  row.className = "ingredient-row"

  row.innerHTML = `
    <input type="text" class="ingredient-input" placeholder="e.g., 1 cup flour" value="${value}" required>
    <button type="button" class="remove-btn">×</button>
  `

  row.querySelector(".remove-btn").addEventListener("click", () => {
    const container = document.getElementById("ingredients-container")
    if (container.children.length > 1) {
      row.remove()
    }
  })

  return row
}

function createInstructionRow(value = "", number = 1) {
  const row = document.createElement("div")
  row.className = "instruction-row"

  row.innerHTML = `
    <span class="step-number">${number}</span>
    <textarea class="instruction-input" placeholder="Describe this step..." rows="2" required>${value}</textarea>
    <button type="button" class="remove-btn">×</button>
  `

  row.querySelector(".remove-btn").addEventListener("click", () => {
    const container = document.getElementById("instructions-container")
    if (container.children.length > 1) {
      row.remove()

      // Update step numbers
      Array.from(container.children).forEach((row, index) => {
        row.querySelector(".step-number").textContent = index + 1
      })
    }
  })

  return row
}

function setupRecipeForm() {
  // Add ingredient row
  document.getElementById("add-ingredient-btn").addEventListener("click", () => {
    const container = document.getElementById("ingredients-container")
    container.appendChild(createIngredientRow())
  })

  // Add instruction row
  document.getElementById("add-instruction-btn").addEventListener("click", () => {
    const container = document.getElementById("instructions-container")
    const newIndex = container.children.length + 1
    container.appendChild(createInstructionRow("", newIndex))
  })
}

function setupFilters() {
  const filterContainer = document.getElementById("filter-tags")

  // Get all unique tags from recipes
  const recipes = getRecipes()
  const allTags = new Set()
  recipes.forEach((recipe) => {
    recipe.tags.forEach((tag) => allTags.add(tag))
  })

  // Create filter tags
  Array.from(allTags)
    .sort()
    .forEach((tag) => {
      const tagElement = document.createElement("div")
      tagElement.className = "filter-tag"
      tagElement.textContent = tag
      tagElement.setAttribute("data-tag", tag)

      tagElement.addEventListener("click", () => {
        tagElement.classList.toggle("active")
        applyFilters()
      })

      filterContainer.appendChild(tagElement)
    })
}

function applyFilters() {
  const activeFilters = Array.from(document.querySelectorAll(".filter-tag.active")).map((tag) =>
    tag.getAttribute("data-tag"),
  )

  const searchTerm = document.getElementById("search-input").value.toLowerCase()
  const recipes = getRecipes()

  let filteredRecipes = recipes

  // Apply search term filter
  if (searchTerm) {
    filteredRecipes = filteredRecipes.filter(
      (recipe) =>
        recipe.title.toLowerCase().includes(searchTerm) ||
        recipe.description.toLowerCase().includes(searchTerm) ||
        recipe.tags.some((tag) => tag.toLowerCase().includes(searchTerm)),
    )
  }

  // Apply tag filters
  if (activeFilters.length > 0) {
    filteredRecipes = filteredRecipes.filter((recipe) => activeFilters.some((tag) => recipe.tags.includes(tag)))
  }

  displayRecipes(filteredRecipes)
}

function handleRecipeSearch() {
  applyFilters()
}

// Form Handlers
function handleLogin(e) {
  e.preventDefault()

  const email = document.getElementById("login-email").value
  const password = document.getElementById("login-password").value

  showLoading()

  login(email, password)
    .then(() => {
      showToast("Login successful", "success")
      navigateTo("/recipes")
    })
    .catch((error) => {
      showToast(error.message, "error")
    })
    .finally(() => {
      hideLoading()
    })
}

function handleRegister(e) {
  e.preventDefault()

  const name = document.getElementById("register-name").value
  const email = document.getElementById("register-email").value
  const password = document.getElementById("register-password").value
  const confirmPassword = document.getElementById("register-confirm-password").value

  if (password !== confirmPassword) {
    showToast("Passwords do not match", "error")
    return
  }

  showLoading()

  register(name, email, password)
    .then(() => {
      showToast("Registration successful", "success")
      navigateTo("/recipes")
    })
    .catch((error) => {
      showToast(error.message, "error")
    })
    .finally(() => {
      hideLoading()
    })
}

function handleForgotPassword(e) {
  e.preventDefault()

  const email = document.getElementById("forgot-email").value

  showLoading()

  resetPassword(email)
    .then(() => {
      showToast("Password reset email sent", "success")
      navigateTo("/login")
    })
    .catch((error) => {
      showToast(error.message, "error")
    })
    .finally(() => {
      hideLoading()
    })
}

function handleCreateRecipe(e) {
  e.preventDefault()

  const recipeData = getRecipeFormData()

  showLoading()

  try {
    const recipe = saveRecipe(recipeData)
    showToast("Recipe created successfully", "success")

    // Send notification email
    const currentUser = getCurrentUser()
    if (window.emailService && currentUser) {
      window.emailService
        .sendRecipeCreationEmail(currentUser.email, currentUser.name, recipe.title)
        .then(() => console.log("Recipe creation email sent"))
        .catch((error) => console.error("Error sending recipe creation email:", error))
    }

    navigateTo("/recipes")
  } catch (error) {
    showToast("An error occurred while saving the recipe", "error")
  } finally {
    hideLoading()
  }
}

function handleEditRecipe(recipeId) {
  const recipeData = getRecipeFormData()
  recipeData.id = recipeId

  showLoading()

  try {
    saveRecipe(recipeData)
    showToast("Recipe updated successfully", "success")
    navigateTo("/recipes/view", { id: recipeId })
  } catch (error) {
    showToast("An error occurred while updating the recipe", "error")
  } finally {
    hideLoading()
  }
}

function getRecipeFormData() {
  const title = document.getElementById("recipe-title").value
  const description = document.getElementById("recipe-description").value
  const prepTime = Number.parseInt(document.getElementById("recipe-prep-time").value)
  const cookTime = Number.parseInt(document.getElementById("recipe-cook-time").value)
  const servings = Number.parseInt(document.getElementById("recipe-servings").value)
  const imageUrl = document.getElementById("recipe-image-url").value

  // Get tags
  const tagsInput = document.getElementById("recipe-tags").value
  const tags = tagsInput
    .split(",")
    .map((tag) => tag.trim())
    .filter((tag) => tag !== "")

  // Get ingredients
  const ingredientInputs = document.querySelectorAll(".ingredient-input")
  const ingredients = Array.from(ingredientInputs)
    .map((input) => input.value.trim())
    .filter((ingredient) => ingredient !== "")

  // Get instructions
  const instructionInputs = document.querySelectorAll(".instruction-input")
  const instructions = Array.from(instructionInputs)
    .map((input) => input.value.trim())
    .filter((instruction) => instruction !== "")

  return {
    title,
    description,
    ingredients,
    instructions,
    prepTime,
    cookTime,
    servings,
    imageUrl,
    tags,
  }
}

// Auth Helper
function checkAuth() {
  const currentUser = getCurrentUser()
  if (!currentUser) {
    showToast("Please log in to continue", "info")
    navigateTo("/login")
    return false
  }
  return true
}

// Initialize App
function init() {
  initializeLocalStorage()

  // Handle browser navigation events
  window.addEventListener("popstate", handleRouteChange)

  // Initial route handling
  handleRouteChange()

  // Expose functions to global scope
  window.recipeBox = {
    showToast,
    closeToast,
    showLoading,
    hideLoading,
  }
}

// Start the app
document.addEventListener("DOMContentLoaded", init)
