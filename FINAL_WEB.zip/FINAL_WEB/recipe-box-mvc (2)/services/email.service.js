const nodemailer = require("nodemailer")

class EmailService {
  constructor() {
    this.transporter = nodemailer.createTransport({
      host: process.env.EMAIL_HOST || "smtp.gmail.com",
      port: process.env.EMAIL_PORT || 587,
      secure: process.env.EMAIL_SECURE === "true",
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
      },
    })
  }

  async sendEmail(to, subject, html) {
    try {
      const mailOptions = {
        from: `"RecipeBox" <${process.env.EMAIL_USER}>`,
        to,
        subject,
        html,
      }

      const info = await this.transporter.sendMail(mailOptions)
      console.log("Email sent:", info.messageId)
      return info
    } catch (error) {
      console.error("Error sending email:", error)
      throw error
    }
  }

  async sendWelcomeEmail(email, name) {
    const subject = "Welcome to RecipeBox!"
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Welcome to RecipeBox, ${name}!</h2>
        <p>Thank you for joining our community of food enthusiasts. With RecipeBox, you can:</p>
        <ul>
          <li>Create and store your favorite recipes</li>
          <li>Discover new recipes from other users</li>
          <li>Save recipes to your personal collection</li>
        </ul>
        <p>We're excited to have you on board!</p>
        <p>Happy cooking,<br>The RecipeBox Team</p>
      </div>
    `

    return this.sendEmail(email, subject, html)
  }

  async sendPasswordResetEmail(email, name, token) {
    const resetUrl = `${process.env.APP_URL}/reset-password?token=${token}`
    const subject = "Reset Your RecipeBox Password"
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Hello, ${name}</h2>
        <p>We received a request to reset your password for your RecipeBox account.</p>
        <p>Click the button below to reset your password:</p>
        <p style="text-align: center;">
          <a href="${resetUrl}" style="display: inline-block; background-color: #f59e0b; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px;">Reset Password</a>
        </p>
        <p>If you didn't request this, you can safely ignore this email.</p>
        <p>This link will expire in 1 hour.</p>
        <p>Best regards,<br>The RecipeBox Team</p>
      </div>
    `

    return this.sendEmail(email, subject, html)
  }

  async sendPasswordChangedEmail(email, name) {
    const subject = "Your RecipeBox Password Has Been Changed"
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Hello, ${name}</h2>
        <p>Your RecipeBox password has been successfully changed.</p>
        <p>If you did not make this change, please contact us immediately.</p>
        <p>Best regards,<br>The RecipeBox Team</p>
      </div>
    `

    return this.sendEmail(email, subject, html)
  }

  async sendRecipeCreationEmail(email, name, recipeTitle) {
    const subject = "Your New Recipe on RecipeBox"
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Hello, ${name}</h2>
        <p>Your new recipe "${recipeTitle}" has been successfully created on RecipeBox!</p>
        <p>Thank you for sharing your culinary creation with our community.</p>
        <p>Happy cooking,<br>The RecipeBox Team</p>
      </div>
    `

    return this.sendEmail(email, subject, html)
  }

  async sendRecipeSavedEmail(email, creatorName, recipeTitle, saverName) {
    const subject = "Someone Saved Your Recipe on RecipeBox"
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Hello, ${creatorName}</h2>
        <p>Great news! ${saverName} has saved your recipe "${recipeTitle}" to their collection.</p>
        <p>Keep sharing your amazing recipes with our community!</p>
        <p>Best regards,<br>The RecipeBox Team</p>
      </div>
    `

    return this.sendEmail(email, subject, html)
  }
}

module.exports = new EmailService()
