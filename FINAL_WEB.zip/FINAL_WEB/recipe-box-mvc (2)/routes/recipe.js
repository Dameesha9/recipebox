// Recipe Routes
const express = require("express")
const RecipeController = require("../controllers/recipe.js")

const router = express.Router()

// Get all recipes
router.get("/", RecipeController.getAll)

// Search recipes
router.get("/search", RecipeController.search)

// Get saved recipes
router.get("/saved", RecipeController.getSavedRecipes)

// Get shared recipes
router.get("/shared", RecipeController.getSharedRecipes)

// Get recipe by ID
router.get("/:id", RecipeController.getById)

// Check if recipe is saved
router.get("/:id/is-saved", RecipeController.isSaved)

// Get share info for a recipe
router.get("/:id/share-info", RecipeController.getShareInfo)

// Create recipe
router.post("/", RecipeController.create)

// Update recipe
router.put("/:id", RecipeController.update)

// Delete recipe
router.delete("/:id", RecipeController.delete)

// Save recipe
router.post("/:id/save", RecipeController.saveRecipe)

// Unsave recipe
router.delete("/:id/save", RecipeController.unsaveRecipe)

// Share recipe
router.post("/:id/share", RecipeController.shareRecipe)

module.exports = router
