// Client-side script for handling recipe sharing
document.addEventListener("DOMContentLoaded", () => {
  // Handle share recipe form submission
  const shareForm = document.getElementById("share-recipe-form")
  if (shareForm) {
    shareForm.addEventListener("submit", async (e) => {
      e.preventDefault()

      const recipientEmail = document.getElementById("recipient-email").value
      const message = document.getElementById("share-message").value
      const recipeId = new URLSearchParams(window.location.search).get("id")

      if (!recipeId) {
        window.recipeBox.showToast("Recipe ID is missing", "error")
        return
      }

      try {
        window.recipeBox.showLoading()

        const response = await window.recipeBox.apiRequest(`/recipes/${recipeId}/share`, "POST", {
          recipientEmail,
          message,
        })

        window.recipeBox.showToast("Recipe shared successfully!", "success")

        // Navigate back to recipe
        window.location.href = `/recipes/${recipeId}`
      } catch (error) {
        window.recipeBox.showToast(error.message, "error")
      } finally {
        window.recipeBox.hideLoading()
      }
    })
  }

  // Handle share button click
  document.addEventListener("click", (e) => {
    if (e.target.id === "share-recipe-btn") {
      const recipeId = e.target.getAttribute("data-id")
      if (recipeId) {
        window.location.href = `/recipes/${recipeId}/share`
      }
    }
  })
})
