// Email Service
// Note: In a real application, this would be handled server-side
// This is a mock implementation for demonstration purposes

class EmailService {
  constructor() {
    // In a real app, this would be configured with actual SMTP settings
    this.configured = true
    this.mockDelay = 1000 // Simulate network delay
  }

  // Mock sending an email
  async sendEmail(to, subject, message) {
    return new Promise((resolve, reject) => {
      // Check if service is configured
      if (!this.configured) {
        setTimeout(() => reject(new Error("Email service not configured")), this.mockDelay)
        return
      }

      // Log the email details (in a real app, this would send the email)
      console.log("Sending email:")
      console.log("To:", to)
      console.log("Subject:", subject)
      console.log("Message:", message)

      // Simulate successful sending
      setTimeout(() => {
        resolve({ success: true, messageId: `mock-${Date.now()}` })
      }, this.mockDelay)
    })
  }

  // Send welcome email to new users
  async sendWelcomeEmail(email, name) {
    const subject = "Welcome to RecipeBox!"
    const message = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Welcome to RecipeBox, ${name}!</h2>
        <p>Thank you for joining our community of food enthusiasts. With RecipeBox, you can:</p>
        <ul>
          <li>Create and store your favorite recipes</li>
          <li>Discover new recipes from other users</li>
          <li>Save recipes to your personal collection</li>
        </ul>
        <p>We're excited to have you on board!</p>
        <p>Happy cooking,<br>The RecipeBox Team</p>
      </div>
    `

    return this.sendEmail(email, subject, message)
  }

  // Send password reset email
  async sendPasswordResetEmail(email, name) {
    const subject = "Reset Your RecipeBox Password"
    const resetToken = Math.random().toString(36).substring(2, 15)
    const message = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Hello, ${name}</h2>
        <p>We received a request to reset your password for your RecipeBox account.</p>
        <p>Your password reset code is: <strong>${resetToken}</strong></p>
        <p>If you didn't request this, you can safely ignore this email.</p>
        <p>Best regards,<br>The RecipeBox Team</p>
      </div>
    `

    return this.sendEmail(email, subject, message)
  }

  // Send notification when a recipe is created
  async sendRecipeCreationEmail(email, name, recipeTitle) {
    const subject = "Your New Recipe on RecipeBox"
    const message = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Hello, ${name}</h2>
        <p>Your new recipe "${recipeTitle}" has been successfully created on RecipeBox!</p>
        <p>Thank you for sharing your culinary creation with our community.</p>
        <p>Happy cooking,<br>The RecipeBox Team</p>
      </div>
    `

    return this.sendEmail(email, subject, message)
  }

  // Send notification when someone saves a recipe
  async sendRecipeSavedEmail(creatorEmail, creatorName, recipeTitle, saverName) {
    const subject = "Someone Saved Your Recipe on RecipeBox"
    const message = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Hello, ${creatorName}</h2>
        <p>Great news! ${saverName} has saved your recipe "${recipeTitle}" to their collection.</p>
        <p>Keep sharing your amazing recipes with our community!</p>
        <p>Best regards,<br>The RecipeBox Team</p>
      </div>
    `

    return this.sendEmail(creatorEmail, subject, message)
  }

  // Share a recipe with a friend
  async shareRecipeWithFriend(recipientEmail, senderName, recipeTitle, recipeUrl, personalMessage = "") {
    const subject = `${senderName} shared a recipe with you: ${recipeTitle}`
    const message = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Hello there!</h2>
        <p>${senderName} thought you might enjoy this recipe for "${recipeTitle}".</p>
        ${personalMessage ? `<p>Message from ${senderName}: "${personalMessage}"</p>` : ""}
        <p>You can view the recipe here: <a href="${recipeUrl}">${recipeTitle}</a></p>
        <p>Happy cooking!<br>The RecipeBox Team</p>
      </div>
    `

    const sendEmailResult = await this.sendEmail(recipientEmail, subject, message)
    this.recordRecipeShare(recipeUrl.split("id=")[1], recipientEmail)
    return sendEmailResult
  }

  // Record that a recipe has been shared
  recordRecipeShare(recipeId, recipientEmail) {
    // Get current user
    const currentUser = JSON.parse(localStorage.getItem("recipeBox_currentUser"))
    if (!currentUser) return false

    // Get or initialize shared recipes record
    const sharedRecipesKey = `recipeBox_sharedRecipes_${currentUser.id}`
    const sharedRecipes = JSON.parse(localStorage.getItem(sharedRecipesKey) || "[]")

    // Add new share record
    sharedRecipes.push({
      recipeId,
      recipientEmail,
      sharedAt: new Date().toISOString(),
    })

    // Save updated records
    localStorage.setItem(sharedRecipesKey, JSON.stringify(sharedRecipes))
    return true
  }
}

// Create a global instance of the email service
const emailService = new EmailService()

// Add event listeners for email-related functionality
document.addEventListener("DOMContentLoaded", () => {
  // Define navigateTo function (assuming it's not globally available)
  const navigateTo =
    window.navigateTo ||
    ((path, params) => {
      let url = path
      if (params) {
        url +=
          "?" +
          Object.entries(params)
            .map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value)}`)
            .join("&")
      }
      window.location.href = url
    })

  // Handle share recipe form submission
  document.addEventListener("submit", (e) => {
    if (e.target.id === "share-recipe-form") {
      e.preventDefault()

      const recipientEmail = document.getElementById("recipient-email").value
      const message = document.getElementById("share-message").value

      // Get current recipe details from the page or local storage
      const currentUser = JSON.parse(localStorage.getItem("recipeBox_currentUser")) || { name: "A RecipeBox User" }
      const recipeId = new URLSearchParams(window.location.search).get("id")
      const recipes = JSON.parse(localStorage.getItem("recipeBox_recipes")) || []
      const recipe = recipes.find((r) => r.id === recipeId) || { title: "A Recipe" }

      // Create a shareable URL (in a real app, this would be a proper URL)
      const recipeUrl = `${window.location.origin}${window.location.pathname}?view=recipes&id=${recipeId}`

      // Show loading
      if (window.recipeBox && window.recipeBox.showLoading) {
        window.recipeBox.showLoading()
      }

      // Send the email
      emailService
        .shareRecipeWithFriend(recipientEmail, currentUser.name, recipe.title, recipeUrl, message)
        .then(() => {
          emailService.recordRecipeShare(recipeId, recipientEmail)
          // Show success message
          if (window.recipeBox && window.recipeBox.showToast) {
            window.recipeBox.showToast("Recipe shared successfully!", "success")
          } else {
            alert("Recipe shared successfully!")
          }

          // Navigate back to recipe
          if (window.navigateTo) {
            navigateTo("/recipes/view", { id: recipeId })
          } else {
            window.location.href = `?view=recipes&id=${recipeId}`
          }
        })
        .catch((error) => {
          // Show error message
          if (window.recipeBox && window.recipeBox.showToast) {
            window.recipeBox.showToast(error.message, "error")
          } else {
            alert(`Error: ${error.message}`)
          }
        })
        .finally(() => {
          // Hide loading
          if (window.recipeBox && window.recipeBox.hideLoading) {
            window.recipeBox.hideLoading()
          }
        })
    }
  })

  // Handle forgot password form submission
  document.addEventListener("submit", (e) => {
    if (e.target.id === "forgot-password-form") {
      e.preventDefault()

      const email = document.getElementById("forgot-email").value
      const users = JSON.parse(localStorage.getItem("recipeBox_users")) || []
      const user = users.find((u) => u.email === email)

      // Show loading
      if (window.recipeBox && window.recipeBox.showLoading) {
        window.recipeBox.showLoading()
      }

      // Send password reset email if user exists
      if (user) {
        emailService
          .sendPasswordResetEmail(email, user.name)
          .then(() => {
            // Show success message
            if (window.recipeBox && window.recipeBox.showToast) {
              window.recipeBox.showToast("Password reset email sent!", "success")
            } else {
              alert("Password reset email sent!")
            }

            // Navigate to login
            if (window.navigateTo) {
              navigateTo("/login")
            } else {
              window.location.href = "?view=login"
            }
          })
          .catch((error) => {
            // Show error message
            if (window.recipeBox && window.recipeBox.showToast) {
              window.recipeBox.showToast(error.message, "error")
            } else {
              alert(`Error: ${error.message}`)
            }
          })
          .finally(() => {
            // Hide loading
            if (window.recipeBox && window.recipeBox.hideLoading) {
              window.recipeBox.hideLoading()
            }
          })
      } else {
        // Don't reveal that the user doesn't exist
        setTimeout(() => {
          if (window.recipeBox && window.recipeBox.showToast) {
            window.recipeBox.showToast("If your email is registered, you will receive a password reset link", "info")
          } else {
            alert("If your email is registered, you will receive a password reset link")
          }

          // Navigate to login
          if (window.navigateTo) {
            navigateTo("/login")
          } else {
            window.location.href = "?view=login"
          }

          // Hide loading
          if (window.recipeBox && window.recipeBox.hideLoading) {
            window.recipeBox.hideLoading()
          }
        }, 1000)
      }
    }
  })

  // Handle register form submission - send welcome email
  document.addEventListener("submit", (e) => {
    if (e.target.id === "register-form") {
      const name = document.getElementById("register-name").value
      const email = document.getElementById("register-email").value

      // This will be called after the main script handles the registration
      const originalHandleRegister = window.handleRegister
      if (originalHandleRegister) {
        window.handleRegister = (event) => {
          originalHandleRegister(event)

          // Send welcome email after successful registration
          const currentUser = JSON.parse(localStorage.getItem("recipeBox_currentUser"))
          if (currentUser) {
            emailService
              .sendWelcomeEmail(email, name)
              .then(() => console.log("Welcome email sent"))
              .catch((error) => console.error("Error sending welcome email:", error))
          }
        }
      }
    }
  })

  // Add share recipe button functionality
  document.addEventListener("click", (e) => {
    if (e.target.id === "share-recipe-btn") {
      e.preventDefault()

      // Get recipe ID from URL
      const recipeId = new URLSearchParams(window.location.search).get("id")

      // Navigate to share recipe form
      if (window.navigateTo) {
        navigateTo("/recipes/share", { id: recipeId })
      } else {
        window.location.href = `?view=share&id=${recipeId}`
      }
    }

    // Back to recipe link in share form
    if (e.target.id === "back-to-recipe") {
      e.preventDefault()

      // Get recipe ID from URL
      const recipeId = new URLSearchParams(window.location.search).get("id")

      // Navigate back to recipe
      if (window.navigateTo) {
        navigateTo("/recipes/view", { id: recipeId })
      } else {
        window.location.href = `?view=recipes&id=${recipeId}`
      }
    }
  })
})
