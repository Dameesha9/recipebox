const express = require("express")
const RecipeController = require("../controllers/recipe.controller")

const router = express.Router()

// Get all recipes
router.get("/", RecipeController.getAll)

// Search recipes
router.get("/search", RecipeController.search)

// Get saved recipes
router.get("/saved", RecipeController.getSavedRecipes)

// Get recipe by ID
router.get("/:id", RecipeController.getById)

// Check if recipe is saved
router.get("/:id/is-saved", RecipeController.isSaved)

// Create recipe
router.post("/", RecipeController.create)

// Update recipe
router.put("/:id", RecipeController.update)

// Delete recipe
router.delete("/:id", RecipeController.delete)

// Save recipe
router.post("/:id/save", RecipeController.saveRecipe)

// Unsave recipe
router.delete("/:id/save", RecipeController.unsaveRecipe)

module.exports = router
