// Saved Recipe model
const fs = require("fs")
const path = require("path")

const dataPath = path.join(__dirname, "..", "data", "saved-recipes.json")

// Ensure data directory exists
const dataDir = path.join(__dirname, "..", "data")
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir)
}

// Initialize saved recipes file if it doesn't exist
if (!fs.existsSync(dataPath)) {
  fs.writeFileSync(dataPath, JSON.stringify({}))
}

class SavedRecipe {
  static async getAll() {
    try {
      const data = fs.readFileSync(dataPath, "utf8")
      return JSON.parse(data)
    } catch (error) {
      console.error("Error reading saved recipes:", error)
      return {}
    }
  }

  static async getByUser(userId) {
    const savedRecipes = await this.getAll()
    return savedRecipes[userId] || []
  }

  static async save(userId, recipeId) {
    try {
      const savedRecipes = await this.getAll()

      if (!savedRecipes[userId]) {
        savedRecipes[userId] = []
      }

      if (!savedRecipes[userId].includes(recipeId)) {
        savedRecipes[userId].push(recipeId)
        fs.writeFileSync(dataPath, JSON.stringify(savedRecipes, null, 2))
      }

      return savedRecipes[userId]
    } catch (error) {
      console.error("Error saving recipe:", error)
      throw error
    }
  }

  static async remove(userId, recipeId) {
    try {
      const savedRecipes = await this.getAll()

      if (!savedRecipes[userId]) {
        return []
      }

      savedRecipes[userId] = savedRecipes[userId].filter((id) => id !== recipeId)
      fs.writeFileSync(dataPath, JSON.stringify(savedRecipes, null, 2))

      return savedRecipes[userId]
    } catch (error) {
      console.error("Error removing saved recipe:", error)
      throw error
    }
  }

  static async isSaved(userId, recipeId) {
    const savedRecipes = await this.getAll()
    return savedRecipes[userId] && savedRecipes[userId].includes(recipeId)
  }
}

module.exports = SavedRecipe
