// Client-side JavaScript for interacting with the API
document.addEventListener("DOMContentLoaded", () => {
  // Initialize the app
  init()

  // Toast functionality
  function showToast(message, type = "info") {
    const toastContainer = document.getElementById("toast-container")
    const toast = document.createElement("div")
    toast.className = `toast toast-${type}`
    toast.innerHTML = `
      <span>${message}</span>
      <button class="toast-close">×</button>
    `

    toastContainer.appendChild(toast)

    // Auto-remove toast after 5 seconds
    setTimeout(() => {
      closeToast(toast)
    }, 5000)

    // Add event listener to close button
    toast.querySelector(".toast-close").addEventListener("click", () => {
      closeToast(toast)
    })
  }

  function closeToast(toast) {
    toast.style.animation = "slideOut 0.3s ease forwards"
    setTimeout(() => {
      toast.remove()
    }, 300)
  }

  // Loading overlay functionality
  function showLoading() {
    const loadingOverlay = document.getElementById("loading-overlay")
    if (loadingOverlay) {
      loadingOverlay.classList.add("visible")
    }
  }

  function hideLoading() {
    const loadingOverlay = document.getElementById("loading-overlay")
    if (loadingOverlay) {
      loadingOverlay.classList.remove("visible")
    }
  }

  // API request helper
  async function apiRequest(url, method = "GET", data = null) {
    showLoading()

    try {
      const options = {
        method,
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        credentials: "same-origin",
      }

      if (data) {
        options.body = JSON.stringify(data)
      }

      const response = await fetch(url, options)
      const result = await response.json()

      if (!response.ok) {
        throw new Error(result.message || "Something went wrong")
      }

      return result
    } catch (error) {
      showToast(error.message, "error")
      throw error
    } finally {
      hideLoading()
    }
  }

  // Router Functions
  const routes = {
    "/": renderHome,
    "/login": renderLogin,
    "/register": renderRegister,
    "/forgot-password": renderForgotPassword,
    "/reset-password": renderResetPassword,
    "/recipes": renderRecipeList,
    "/recipes/new": renderCreateRecipe,
    "/recipes/edit": renderEditRecipe,
    "/recipes/view": renderRecipeDetail,
    "/recipes/share": renderShareRecipe,
    "/recipes/shared": renderSharedRecipes,
    "/saved-recipes": renderSavedRecipes,
    "/profile": renderProfile,
  }

  function navigateTo(path, params = {}) {
    // Set URL parameters if provided
    let url = path
    const searchParams = new URLSearchParams()

    for (const [key, value] of Object.entries(params)) {
      searchParams.set(key, value)
    }

    const searchParamsString = searchParams.toString()
    if (searchParamsString) {
      url = `${url}?${searchParamsString}`
    }

    window.history.pushState({ path: url }, "", url)
    handleRouteChange()
  }

  function getUrlParams() {
    const searchParams = new URLSearchParams(window.location.search)
    const params = {}

    for (const [key, value] of searchParams.entries()) {
      params[key] = value
    }

    return params
  }

  function handleRouteChange() {
    const path = window.location.pathname || "/"
    const renderFunction = routes[path] || renderNotFound

    const mainContent = document.getElementById("main-content")
    mainContent.innerHTML = ""

    renderFunction()
    updateNav()
  }

  // Page Rendering Functions
  function renderHome() {
    // Fetch current user
    apiRequest("/users/profile")
      .then((data) => {
        const user = data.user

        // Render home page with user data
        const mainContent = document.getElementById("main-content")
        mainContent.innerHTML = `
          <section class="hero">
            <div class="hero-content">
              <h1>Your recipe collection, <span>organized</span></h1>
              <p>Save, organize, and discover your favorite recipes in one place.</p>
              <div class="hero-buttons">
                ${
                  user
                    ? `
                  <button class="btn btn-primary" id="my-recipes-btn">My Recipes</button>
                `
                    : `
                  <button class="btn btn-primary" id="login-btn">Get Started</button>
                `
                }
                <button class="btn btn-outline" id="browse-recipes-btn">Browse Recipes</button>
              </div>
            </div>
            <div class="hero-image">
              <img src="https://images.unsplash.com/photo-1498837167922-ddd27525d352?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" alt="Cooking ingredients">
            </div>
          </section>
          
          <section class="features">
            <h2>Features for the home chef</h2>
            <div class="features-grid">
              <div class="feature">
                <div class="feature-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                    <path d="M14 2v6h6"></path>
                    <path d="M16 13H8"></path>
                    <path d="M16 17H8"></path>
                    <path d="M10 9H8"></path>
                  </svg>
                </div>
                <h3>Create & Edit</h3>
                <p>Easily add your own recipes or edit existing ones to make them perfect.</p>
              </div>
              
              <div class="feature">
                <div class="feature-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"></path>
                  </svg>
                </div>
                <h3>Save & Organize</h3>
                <p>Save recipes you love and organize them in your personal collection.</p>
              </div>
              
              <div class="feature">
                <div class="feature-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="11" cy="11" r="8"></circle>
                    <path d="m21 21-4.3-4.3"></path>
                  </svg>
                </div>
                <h3>Search & Filter</h3>
                <p>Find exactly what you're craving with powerful search and filtering tools.</p>
              </div>
            </div>
          </section>
          
          <section class="cta">
            <div class="cta-content">
              <h2>Start building your recipe collection today</h2>
              <p>Join thousands of home chefs who are storing, sharing, and discovering new recipes on recipeBox.</p>
              ${
                user
                  ? `
                <button class="btn btn-light" id="create-recipe-btn">Create New Recipe</button>
              `
                  : `
                <button class="btn btn-light" id="signup-btn">Sign Up for Free</button>
              `
              }
            </div>
          </section>
        `

        // Add event listeners
        if (user) {
          document.getElementById("my-recipes-btn").addEventListener("click", () => {
            navigateTo("/recipes")
          })

          document.getElementById("create-recipe-btn").addEventListener("click", () => {
            navigateTo("/recipes/new")
          })
        } else {
          document.getElementById("login-btn").addEventListener("click", () => {
            navigateTo("/login")
          })

          document.getElementById("signup-btn").addEventListener("click", () => {
            navigateTo("/register")
          })
        }

        document.getElementById("browse-recipes-btn").addEventListener("click", () => {
          navigateTo("/recipes")
        })
      })
      .catch(() => {
        // If error (not logged in), render default home page
        const mainContent = document.getElementById("main-content")
        mainContent.innerHTML = `
          <section class="hero">
            <div class="hero-content">
              <h1>Your recipe collection, <span>organized</span></h1>
              <p>Save, organize, and discover your favorite recipes in one place.</p>
              <div class="hero-buttons">
                <button class="btn btn-primary" id="login-btn">Get Started</button>
                <button class="btn btn-outline" id="browse-recipes-btn">Browse Recipes</button>
              </div>
            </div>
            <div class="hero-image">
              <img src="https://images.unsplash.com/photo-1498837167922-ddd27525d352?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" alt="Cooking ingredients">
              alt="Cooking ingredients">
            </div>
          </section>
          
          <section class="features">
            <h2>Features for the home chef</h2>
            <div class="features-grid">
              <div class="feature">
                <div class="feature-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                    <path d="M14 2v6h6"></path>
                    <path d="M16 13H8"></path>
                    <path d="M16 17H8"></path>
                    <path d="M10 9H8"></path>
                  </svg>
                </div>
                <h3>Create & Edit</h3>
                <p>Easily add your own recipes or edit existing ones to make them perfect.</p>
              </div>
              
              <div class="feature">
                <div class="feature-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"></path>
                  </svg>
                </div>
                <h3>Save & Organize</h3>
                <p>Save recipes you love and organize them in your personal collection.</p>
              </div>
              
              <div class="feature">
                <div class="feature-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="11" cy="11" r="8"></circle>
                    <path d="m21 21-4.3-4.3"></path>
                  </svg>
                </div>
                <h3>Search & Filter</h3>
                <p>Find exactly what you're craving with powerful search and filtering tools.</p>
              </div>
            </div>
          </section>
          
          <section class="cta">
            <div class="cta-content">
              <h2>Start building your recipe collection today</h2>
              <p>Join thousands of home chefs who are storing, sharing, and discovering new recipes on recipeBox.</p>
              <button class="btn btn-light" id="signup-btn">Sign Up for Free</button>
            </div>
          </section>
        `

        // Add event listeners
        document.getElementById("login-btn").addEventListener("click", () => {
          navigateTo("/login")
        })

        document.getElementById("signup-btn").addEventListener("click", () => {
          navigateTo("/register")
        })

        document.getElementById("browse-recipes-btn").addEventListener("click", () => {
          navigateTo("/recipes")
        })
      })
  }

  function renderLogin() {
    const mainContent = document.getElementById("main-content")
    mainContent.innerHTML = `
      <div class="auth-container">
        <h2>Welcome Back</h2>
        <p>Log in to access your recipes</p>
        
        <form id="login-form" class="auth-form">
          <div class="form-group">
            <label for="login-email">Email</label>
            <input type="email" id="login-email" placeholder="Your email" required>
          </div>
          
          <div class="form-group">
            <label for="login-password">Password</label>
            <input type="password" id="login-password" placeholder="Your password" required>
          </div>
          
          <div class="form-links">
            <a href="#" id="forgot-password-link">Forgot password?</a>
          </div>
          
          <button type="submit" class="btn btn-primary btn-block">Log In</button>
          
          <div class="auth-footer">
            <p>Don't have an account? <a href="#" id="register-link">Register</a></p>
          </div>
        </form>
      </div>
    `

    // Add event listeners
    document.getElementById("login-form").addEventListener("submit", (e) => {
      e.preventDefault()

      const email = document.getElementById("login-email").value
      const password = document.getElementById("login-password").value

      apiRequest("/auth/login", "POST", { email, password })
        .then(() => {
          showToast("Login successful", "success")
          navigateTo("/recipes")
        })
        .catch((error) => {
          showToast(error.message, "error")
        })
    })

    document.getElementById("forgot-password-link").addEventListener("click", (e) => {
      e.preventDefault()
      navigateTo("/forgot-password")
    })

    document.getElementById("register-link").addEventListener("click", (e) => {
      e.preventDefault()
      navigateTo("/register")
    })
  }

  function renderRegister() {
    const mainContent = document.getElementById("main-content")
    mainContent.innerHTML = `
      <div class="auth-container">
        <h2>Create an Account</h2>
        <p>Join recipeBox to start saving your recipes</p>
        
        <form id="register-form" class="auth-form">
          <div class="form-group">
            <label for="register-name">Name</label>
            <input type="text" id="register-name" placeholder="Your name" required>
          </div>
          
          <div class="form-group">
            <label for="register-email">Email</label>
            <input type="email" id="register-email" placeholder="Your email" required>
          </div>
          
          <div class="form-group">
            <label for="register-password">Password</label>
            <input type="password" id="register-password" placeholder="Password (8+ characters with special character)" required>
            <div class="password-requirements">
              Password must be at least 8 characters and contain at least one special character (!@#$%^&*).
            </div>
          </div>
          
          <div class="form-group">
            <label for="register-confirm-password">Confirm Password</label>
            <input type="password" id="register-confirm-password" placeholder="Confirm password" required>
          </div>
          
          <button type="submit" class="btn btn-primary btn-block">Register</button>
          
          <div class="auth-footer">
            <p>Already have an account? <a href="#" id="login-link">Log in</a></p>
          </div>
        </form>
      </div>
    `

    // Add event listeners
    document.getElementById("register-form").addEventListener("submit", (e) => {
      e.preventDefault()

      const name = document.getElementById("register-name").value
      const email = document.getElementById("register-email").value
      const password = document.getElementById("register-password").value
      const confirmPassword = document.getElementById("register-confirm-password").value

      if (password !== confirmPassword) {
        showToast("Passwords do not match", "error")
        return
      }

      apiRequest("/auth/register", "POST", { name, email, password })
        .then(() => {
          showToast("Registration successful", "success")
          navigateTo("/recipes")
        })
        .catch((error) => {
          showToast(error.message, "error")
        })
    })

    document.getElementById("login-link").addEventListener("click", (e) => {
      e.preventDefault()
      navigateTo("/login")
    })
  }

  function renderForgotPassword() {
    const mainContent = document.getElementById("main-content")
    mainContent.innerHTML = `
      <div class="auth-container">
        <h2>Reset Password</h2>
        <p>Enter your email to receive a password reset link</p>
        
        <form id="forgot-password-form" class="auth-form">
          <div class="form-group">
            <label for="forgot-email">Email</label>
            <input type="email" id="forgot-email" placeholder="Your email" required>
          </div>
          
          <button type="submit" class="btn btn-primary btn-block">Send Reset Link</button>
          
          <div class="auth-footer">
            <p><a href="#" id="back-to-login">Back to login</a></p>
          </div>
        </form>
      </div>
    `

    // Add event listeners
    document.getElementById("forgot-password-form").addEventListener("submit", (e) => {
      e.preventDefault()

      const email = document.getElementById("forgot-email").value

      apiRequest("/auth/forgot-password", "POST", { email })
        .then(() => {
          showToast("Password reset email sent", "success")
          navigateTo("/login")
        })
        .catch((error) => {
          showToast(error.message, "error")
        })
    })

    document.getElementById("back-to-login").addEventListener("click", (e) => {
      e.preventDefault()
      navigateTo("/login")
    })
  }

  function renderResetPassword() {
    const params = getUrlParams()
    const token = params.token

    if (!token) {
      navigateTo("/login")
      return
    }

    const mainContent = document.getElementById("main-content")
    mainContent.innerHTML = `
      <div class="auth-container">
        <h2>Set New Password</h2>
        <p>Enter your new password</p>
        
        <form id="reset-password-form" class="auth-form">
          <input type="hidden" id="reset-token" value="${token}">
          
          <div class="form-group">
            <label for="new-password">New Password</label>
            <input type="password" id="new-password" placeholder="New password (8+ characters with special character)" required>
            <div class="password-requirements">
              Password must be at least 8 characters and contain at least one special character (!@#$%^&*).
            </div>
          </div>
          
          <div class="form-group">
            <label for="confirm-new-password">Confirm New Password</label>
            <input type="password" id="confirm-new-password" placeholder="Confirm new password" required>
          </div>
          
          <button type="submit" class="btn btn-primary btn-block">Reset Password</button>
        </form>
      </div>
    `

    // Add event listeners
    document.getElementById("reset-password-form").addEventListener("submit", (e) => {
      e.preventDefault()

      const token = document.getElementById("reset-token").value
      const password = document.getElementById("new-password").value
      const confirmPassword = document.getElementById("confirm-new-password").value

      if (password !== confirmPassword) {
        showToast("Passwords do not match", "error")
        return
      }

      apiRequest("/auth/reset-password", "POST", { token, password })
        .then(() => {
          showToast("Password reset successful", "success")
          navigateTo("/login")
        })
        .catch((error) => {
          showToast(error.message, "error")
        })
    })
  }

  function renderRecipeList() {
    apiRequest("/recipes")
      .then((data) => {
        const recipes = data.recipes

        const mainContent = document.getElementById("main-content")
        mainContent.innerHTML = `
          <div class="page-header">
            <h1>All Recipes</h1>
            <p>Browse our collection of delicious recipes</p>
          </div>
          
          <div class="search-container">
            <div class="search-box">
              <input type="text" id="search-input" placeholder="Search recipes...">
              <button id="search-button" class="btn btn-primary">Search</button>
            </div>
            
            <div class="filter-section">
              <h3>Filter by tags</h3>
              <div id="filter-tags" class="filter-tags"></div>
            </div>
          </div>
          
          <div id="recipe-list" class="recipe-grid"></div>
          
          <div class="recipe-actions">
            <button id="add-recipe-btn" class="btn btn-primary">Add New Recipe</button>
          </div>
        `

        // Add event listeners
        document.getElementById("search-button").addEventListener("click", handleRecipeSearch)
        document.getElementById("search-input").addEventListener("keypress", (e) => {
          if (e.key === "Enter") {
            handleRecipeSearch()
          }
        })

        document.getElementById("add-recipe-btn").addEventListener("click", () => {
          navigateTo("/recipes/new")
        })

        // Display recipes
        displayRecipes(recipes)

        // Setup filters
        setupFilters(recipes)
      })
      .catch((error) => {
        showToast(error.message, "error")
      })
  }

  function renderSavedRecipes() {
    apiRequest("/recipes/saved")
      .then((data) => {
        const recipes = data.recipes

        const mainContent = document.getElementById("main-content")
        mainContent.innerHTML = `
          <div class="page-header">
            <h1>My Collection</h1>
            <p>Your saved recipes</p>
          </div>
          
          <div id="saved-recipe-list" class="recipe-grid"></div>
          
          <div id="empty-saved-recipes" class="empty-state hidden">
            <div class="empty-icon">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"></path>
              </svg>
            </div>
            <h3>No saved recipes yet</h3>
            <p>Start saving your favorite recipes to see them here.</p>
            <button id="browse-from-empty" class="btn btn-primary">Browse Recipes</button>
          </div>
        `

        // Show empty state or recipes
        const recipeListContainer = document.getElementById("saved-recipe-list")
        const emptyStateContainer = document.getElementById("empty-saved-recipes")

        if (recipes.length === 0) {
          recipeListContainer.classList.add("hidden")
          emptyStateContainer.classList.remove("hidden")
          document.getElementById("browse-from-empty").addEventListener("click", () => {
            navigateTo("/recipes")
          })
        } else {
          recipeListContainer.classList.remove("hidden")
          emptyStateContainer.classList.add("hidden")
          recipes.forEach((recipe) => {
            recipeListContainer.appendChild(createRecipeCard(recipe, true))
          })
        }
      })
      .catch((error) => {
        showToast(error.message, "error")
      })
  }

  function renderSharedRecipes() {
    apiRequest("/recipes/shared")
      .then((data) => {
        const recipes = data.recipes

        const mainContent = document.getElementById("main-content")
        mainContent.innerHTML = `
          <div class="page-header">
            <h1>Shared Recipes</h1>
            <p>Recipes you've shared with others</p>
          </div>
          
          <div id="shared-recipe-list" class="recipe-grid"></div>
          
          <div id="empty-shared-recipes" class="empty-state hidden">
            <div class="empty-icon">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"></path>
                <polyline points="16 6 12 2 8 6"></polyline>
                <line x1="12" y1="2" x2="12" y2="15"></line>
              </svg>
            </div>
            <h3>No shared recipes yet</h3>
            <p>Share your favorite recipes with friends to see them here.</p>
            <button id="browse-from-empty" class="btn btn-primary">Browse Recipes</button>
          </div>
        `

        // Show empty state or recipes
        const recipeListContainer = document.getElementById("shared-recipe-list")
        const emptyStateContainer = document.getElementById("empty-shared-recipes")

        if (recipes.length === 0) {
          recipeListContainer.classList.add("hidden")
          emptyStateContainer.classList.remove("hidden")
          document.getElementById("browse-from-empty").addEventListener("click", () => {
            navigateTo("/recipes")
          })
        } else {
          recipeListContainer.classList.remove("hidden")
          emptyStateContainer.classList.add("hidden")
          recipes.forEach((recipe) => {
            const card = createRecipeCard(recipe)

            // Add share count badge
            if (recipe.shareCount) {
              const shareInfo = document.createElement("div")
              shareInfo.className = "share-info"
              shareInfo.innerHTML = `<span>Shared ${recipe.shareCount} time${recipe.shareCount !== 1 ? "s" : ""}</span>`
              card.querySelector(".recipe-card-content").appendChild(shareInfo)
            }

            recipeListContainer.appendChild(card)
          })
        }
      })
      .catch((error) => {
        showToast(error.message, "error")
      })
  }

  function renderCreateRecipe() {
    const mainContent = document.getElementById("main-content")
    mainContent.innerHTML = `
      <div class="page-header">
        <h1>Add Recipe</h1>
        <p>Share your culinary creation with the world</p>
      </div>
      
      <form id="recipe-form" class="recipe-form">
        <div class="form-section">
          <h3>Basic Information</h3>
          
          <div class="form-group">
            <label for="recipe-title">Recipe Title</label>
            <input type="text" id="recipe-title" placeholder="e.g., Chocolate Chip Cookies" required>
          </div>
          
          <div class="form-group">
            <label for="recipe-description">Description</label>
            <textarea id="recipe-description" placeholder="Briefly describe your recipe" rows="3" required></textarea>
          </div>
          
          <div class="form-row">
            <div class="form-group">
              <label for="recipe-prep-time">Prep Time (min)</label>
              <input type="number" id="recipe-prep-time" placeholder="15" min="1" required>
            </div>
            
            <div class="form-group">
              <label for="recipe-cook-time">Cook Time (min)</label>
              <input type="number" id="recipe-cook-time" placeholder="20" min="1" required>
            </div>
            
            <div class="form-group">
              <label for="recipe-servings">Servings</label>
              <input type="number" id="recipe-servings" placeholder="4" min="1" required>
            </div>
          </div>
          
          <div class="form-group">
            <label for="recipe-image-url">Image URL (optional)</label>
            <input type="url" id="recipe-image-url" placeholder="https://example.com/my-recipe-image.jpg">
          </div>
          
          <div class="form-group">
            <label for="recipe-tags">Tags (comma separated)</label>
            <input type="text" id="recipe-tags" placeholder="e.g., dessert, vegetarian, quick">
          </div>
        </div>
        
        <div class="form-section">
          <h3>Ingredients</h3>
          <div id="ingredients-container">
            <div class="ingredient-row">
              <input type="text" class="ingredient-input" placeholder="e.g., 1 cup flour" required>
              <button type="button" class="remove-btn">×</button>
            </div>
            <div class="ingredient-row">
              <input type="text" class="ingredient-input" placeholder="e.g., 2 eggs" required>
              <button type="button" class="remove-btn">×</button>
            </div>
          </div>
          <button type="button" id="add-ingredient-btn" class="btn btn-outline btn-small">Add Ingredient</button>
        </div>
        
        <div class="form-section">
          <h3>Instructions</h3>
          <div id="instructions-container">
            <div class="instruction-row">
              <span class="step-number">1</span>
              <textarea class="instruction-input" placeholder="Describe this step..." rows="2" required></textarea>
              <button type="button" class="remove-btn">×</button>
            </div>
            <div class="instruction-row">
              <span class="step-number">2</span>
              <textarea class="instruction-input" placeholder="Describe this step..." rows="2" required></textarea>
              <button type="button" class="remove-btn">×</button>
            </div>
          </div>
          <button type="button" id="add-instruction-btn" class="btn btn-outline btn-small">Add Instruction</button>
        </div>
        
        <div class="form-actions">
          <button type="button" id="cancel-recipe-btn" class="btn btn-outline">Cancel</button>
          <button type="submit" id="save-recipe-btn" class="btn btn-primary">Create Recipe</button>
        </div>
      </form>
    `

    // Setup recipe form
    setupRecipeForm()

    // Add event listeners
    document.getElementById("recipe-form").addEventListener("submit", (e) => {
      e.preventDefault()

      const recipeData = getRecipeFormData()

      apiRequest("/recipes", "POST", recipeData)
        .then(() => {
          showToast("Recipe created successfully", "success")
          navigateTo("/recipes")
        })
        .catch((error) => {
          showToast(error.message, "error")
        })
    })

    document.getElementById("cancel-recipe-btn").addEventListener("click", () => {
      navigateTo("/recipes")
    })
  }

  function renderEditRecipe() {
    const params = getUrlParams()
    const recipeId = params.id

    if (!recipeId) {
      navigateTo("/recipes")
      return
    }

    apiRequest(`/recipes/${recipeId}`)
      .then((data) => {
        const recipe = data.recipe

        const mainContent = document.getElementById("main-content")
        mainContent.innerHTML = `
          <div class="page-header">
            <h1>Edit Recipe</h1>
            <p>Update your recipe</p>
          </div>
          
          <form id="recipe-form" class="recipe-form">
            <div class="form-section">
              <h3>Basic Information</h3>
              
              <div class="form-group">
                <label for="recipe-title">Recipe Title</label>
                <input type="text" id="recipe-title" value="${recipe.title}" required>
              </div>
              
              <div class="form-group">
                <label for="recipe-description">Description</label>
                <textarea id="recipe-description" rows="3" required>${recipe.description}</textarea>
              </div>
              
              <div class="form-row">
                <div class="form-group">
                  <label for="recipe-prep-time">Prep Time (min)</label>
                  <input type="number" id="recipe-prep-time" value="${recipe.prepTime}" min="1" required>
                </div>
                
                <div class="form-group">
                  <label for="recipe-cook-time">Cook Time (min)</label>
                  <input type="number" id="recipe-cook-time" value="${recipe.cookTime}" min="1" required>
                </div>
                
                <div class="form-group">
                  <label for="recipe-servings">Servings</label>
                  <input type="number" id="recipe-servings" value="${recipe.servings}" min="1" required>
                </div>
              </div>
              
              <div class="form-group">
                <label for="recipe-image-url">Image URL (optional)</label>
                <input type="url" id="recipe-image-url" value="${recipe.imageUrl || ""}">
              </div>
              
              <div class="form-group">
                <label for="recipe-tags">Tags (comma separated)</label>
                <input type="text" id="recipe-tags" value="${recipe.tags.join(", ")}">
              </div>
            </div>
            
            <div class="form-section">
              <h3>Ingredients</h3>
              <div id="ingredients-container"></div>
              <button type="button" id="add-ingredient-btn" class="btn btn-outline btn-small">Add Ingredient</button>
            </div>
            
            <div class="form-section">
              <h3>Instructions</h3>
              <div id="instructions-container"></div>
              <button type="button" id="add-instruction-btn" class="btn btn-outline btn-small">Add Instruction</button>
            </div>
            
            <div class="form-actions">
              <button type="button" id="cancel-recipe-btn" class="btn btn-outline">Cancel</button>
              <button type="submit" id="save-recipe-btn" class="btn btn-primary">Update Recipe</button>
            </div>
          </form>
        `

        // Add ingredients
        const ingredientsContainer = document.getElementById("ingredients-container")
        recipe.ingredients.forEach((ingredient) => {
          ingredientsContainer.appendChild(createIngredientRow(ingredient))
        })

        // Add instructions
        const instructionsContainer = document.getElementById("instructions-container")
        recipe.instructions.forEach((instruction, index) => {
          instructionsContainer.appendChild(createInstructionRow(instruction, index + 1))
        })

        // Setup recipe form
        setupRecipeForm()

        // Add event listeners
        document.getElementById("recipe-form").addEventListener("submit", (e) => {
          e.preventDefault()

          const recipeData = getRecipeFormData()

          apiRequest(`/recipes/${recipeId}`, "PUT", recipeData)
            .then(() => {
              showToast("Recipe updated successfully", "success")
              navigateTo("/recipes/view", { id: recipeId })
            })
            .catch((error) => {
              showToast(error.message, "error")
            })
        })

        document.getElementById("cancel-recipe-btn").addEventListener("click", () => {
          navigateTo("/recipes/view", { id: recipeId })
        })
      })
      .catch((error) => {
        showToast(error.message, "error")
        navigateTo("/recipes")
      })
  }

  function renderRecipeDetail() {
    const params = getUrlParams()
    const recipeId = params.id

    if (!recipeId) {
      navigateTo("/recipes")
      return
    }

    Promise.all([
      apiRequest(`/recipes/${recipeId}`),
      apiRequest(`/recipes/${recipeId}/is-saved`),
      apiRequest(`/recipes/${recipeId}/share-info`),
    ])
      .then(([recipeData, savedData, shareData]) => {
        const recipe = recipeData.recipe
        const isSaved = savedData.isSaved
        const isShared = shareData.isShared
        const shareCount = shareData.shareCount

        const mainContent = document.getElementById("main-content")
        mainContent.innerHTML = `
          <div class="recipe-detail">
            <div class="recipe-header">
              <h1>${recipe.title}</h1>
              <p class="recipe-description">${recipe.description}</p>
              
              <div class="recipe-meta">
                <span>Prep: ${recipe.prepTime} min</span>
                <span class="meta-separator">•</span>
                <span>Cook: ${recipe.cookTime} min</span>
                <span class="meta-separator">•</span>
                <span>Serves: ${recipe.servings}</span>
              </div>
              
              <div class="recipe-tags">
                ${recipe.tags.map((tag) => `<span class="recipe-tag">${tag}</span>`).join("")}
              </div>
              
              <div class="recipe-actions">
                <button id="save-recipe-btn" class="btn btn-outline">${isSaved ? "Unsave Recipe" : "Save Recipe"}</button>
                <button id="edit-recipe-btn" class="btn btn-outline">Edit</button>
                <button id="delete-recipe-btn" class="btn btn-danger">Delete</button>
                <button id="share-recipe-btn" class="btn btn-primary">Share Recipe</button>
                ${isShared ? `<div class="share-info"><span>Shared ${shareCount} time${shareCount !== 1 ? "s" : ""}</span></div>` : ""}
              </div>
            </div>
            
            <div class="recipe-image-container">
              <img src="${recipe.imageUrl || "https://via.placeholder.com/800x500?text=No+Image"}" alt="${recipe.title}">
            </div>
            
            <div class="recipe-content">
              <div class="ingredients-section">
                <h2>Ingredients</h2>
                <ul>
                  ${recipe.ingredients.map((ingredient) => `<li>${ingredient}</li>`).join("")}
                </ul>
              </div>
              
              <div class="instructions-section">
                <h2>Instructions</h2>
                <ol>
                  ${recipe.instructions.map((instruction) => `<li>${instruction}</li>`).join("")}
                </ol>
              </div>
            </div>
          </div>
        `

        // Check if user is the creator
        apiRequest("/users/profile")
          .then((userData) => {
            const user = userData.user
            const isOwner = user.id === recipe.createdBy

            // Show/hide edit and delete buttons based on ownership
            if (!isOwner) {
              document.getElementById("edit-recipe-btn").classList.add("hidden")
              document.getElementById("delete-recipe-btn").classList.add("hidden")
            }
          })
          .catch(() => {
            // If error (not logged in), hide edit and delete buttons
            document.getElementById("edit-recipe-btn").classList.add("hidden")
            document.getElementById("delete-recipe-btn").classList.add("hidden")
          })

        // Add event listeners
        document.getElementById("save-recipe-btn").addEventListener("click", () => {
          const saveButton = document.getElementById("save-recipe-btn")

          if (isSaved) {
            apiRequest(`/recipes/${recipeId}/save`, "DELETE")
              .then(() => {
                saveButton.textContent = "Save Recipe"
                showToast("Recipe removed from your collection", "success")
              })
              .catch((error) => {
                showToast(error.message, "error")
              })
          } else {
            apiRequest(`/recipes/${recipeId}/save`, "POST")
              .then(() => {
                saveButton.textContent = "Unsave Recipe"
                showToast("Recipe saved to your collection", "success")
              })
              .catch((error) => {
                showToast(error.message, "error")
              })
          }
        })

        document.getElementById("edit-recipe-btn").addEventListener("click", () => {
          navigateTo("/recipes/edit", { id: recipeId })
        })

        document.getElementById("delete-recipe-btn").addEventListener("click", () => {
          if (confirm("Are you sure you want to delete this recipe?")) {
            apiRequest(`/recipes/${recipeId}`, "DELETE")
              .then(() => {
                showToast("Recipe deleted successfully", "success")
                navigateTo("/recipes")
              })
              .catch((error) => {
                showToast(error.message, "error")
              })
          }
        })

        document.getElementById("share-recipe-btn").addEventListener("click", () => {
          navigateTo("/recipes/share", { id: recipeId })
        })
      })
      .catch((error) => {
        showToast(error.message, "error")
        navigateTo("/recipes")
      })
  }

  function renderShareRecipe() {
    const params = getUrlParams()
    const recipeId = params.id

    if (!recipeId) {
      navigateTo("/recipes")
      return
    }

    apiRequest(`/recipes/${recipeId}`)
      .then((data) => {
        const recipe = data.recipe

        const mainContent = document.getElementById("main-content")
        mainContent.innerHTML = `
          <div class="auth-container">
            <h2>Share Recipe</h2>
            <p>Share "${recipe.title}" with your friends</p>
            
            <form id="share-recipe-form" class="auth-form">
              <div class="form-group">
                <label for="recipient-email">Recipient Email</label>
                <input type="email" id="recipient-email" placeholder="friend@example.com" required>
              </div>
              
              <div class="form-group">
                <label for="share-message">Message (optional)</label>
                <textarea id="share-message" placeholder="Check out this amazing recipe!" rows="3"></textarea>
              </div>
              
              <button type="submit" class="btn btn-primary btn-block">Send Recipe</button>
              
              <div class="auth-footer">
                <p><a href="#" id="back-to-recipe">Back to recipe</a></p>
              </div>
            </form>
          </div>
        `

        // Add event listeners
        document.getElementById("share-recipe-form").addEventListener("submit", (e) => {
          e.preventDefault()

          const recipientEmail = document.getElementById("recipient-email").value
          const message = document.getElementById("share-message").value

          apiRequest(`/recipes/${recipeId}/share`, "POST", { recipientEmail, message })
            .then(() => {
              showToast("Recipe shared successfully!", "success")
              navigateTo("/recipes/view", { id: recipeId })
            })
            .catch((error) => {
              showToast(error.message, "error")
            })
        })

        document.getElementById("back-to-recipe").addEventListener("click", (e) => {
          e.preventDefault()
          navigateTo("/recipes/view", { id: recipeId })
        })
      })
      .catch((error) => {
        showToast(error.message, "error")
        navigateTo("/recipes")
      })
  }

  function renderProfile() {
    apiRequest("/users/profile")
      .then((data) => {
        const user = data.user

        const mainContent = document.getElementById("main-content")
        mainContent.innerHTML = `
          <div class="page-header">
            <h1>Your Profile</h1>
            <p>Manage your account information</p>
          </div>
          
          <div class="profile-container">
            <div class="profile-section">
              <h2>Account Information</h2>
              
              <form id="profile-form" class="auth-form">
                <div class="form-group">
                  <label for="profile-name">Name</label>
                  <input type="text" id="profile-name" value="${user.name}" required>
                </div>
                
                <div class="form-group">
                  <label for="profile-email">Email</label>
                  <input type="email" id="profile-email" value="${user.email}" required>
                </div>
                
                <button type="submit" class="btn btn-primary">Update Profile</button>
              </form>
            </div>
            
            <div class="profile-section">
              <h2>Change Password</h2>
              
              <form id="password-form" class="auth-form">
                <div class="form-group">
                  <label for="current-password">Current Password</label>
                  <input type="password" id="current-password" required>
                </div>
                
                <div class="form-group">
                  <label for="new-password">New Password</label>
                  <input type="password" id="new-password" required>
                  <div class="password-requirements">
                    Password must be at least 8 characters and contain at least one special character (!@#$%^&*).
                  </div>
                </div>
                
                <div class="form-group">
                  <label for="confirm-password">Confirm New Password</label>
                  <input type="password" id="confirm-password" required>
                </div>
                
                <button type="submit" class="btn btn-primary">Change Password</button>
              </form>
            </div>
          </div>
        `

        // Add event listeners
        document.getElementById("profile-form").addEventListener("submit", (e) => {
          e.preventDefault()

          const name = document.getElementById("profile-name").value
          const email = document.getElementById("profile-email").value

          apiRequest("/users/profile", "PUT", { name, email })
            .then(() => {
              showToast("Profile updated successfully", "success")
              updateNav()
            })
            .catch((error) => {
              showToast(error.message, "error")
            })
        })

        document.getElementById("password-form").addEventListener("submit", (e) => {
          e.preventDefault()

          const currentPassword = document.getElementById("current-password").value
          const newPassword = document.getElementById("new-password").value
          const confirmPassword = document.getElementById("confirm-password").value

          if (newPassword !== confirmPassword) {
            showToast("Passwords do not match", "error")
            return
          }

          apiRequest("/users/change-password", "POST", { currentPassword, newPassword })
            .then(() => {
              showToast("Password changed successfully", "success")
              document.getElementById("password-form").reset()
            })
            .catch((error) => {
              showToast(error.message, "error")
            })
        })
      })
      .catch((error) => {
        showToast(error.message, "error")
        navigateTo("/login")
      })
  }

  function renderNotFound() {
    const mainContent = document.getElementById("main-content")
    mainContent.innerHTML = `
      <div class="not-found">
        <h1>404</h1>
        <p>Page not found</p>
        <button id="go-home-btn" class="btn btn-primary">Go Home</button>
      </div>
    `

    document.getElementById("go-home-btn").addEventListener("click", () => {
      navigateTo("/")
    })
  }

  // Helper UI Functions
  function updateNav() {
    apiRequest("/users/profile")
      .then((data) => {
        const user = data.user

        const nav = document.getElementById("main-nav")
        nav.innerHTML = `
          <ul>
            <li><a href="#" class="nav-link" data-route="/">Home</a></li>
            <li><a href="#" class="nav-link" data-route="/recipes">Recipes</a></li>
            <li><a href="#" class="nav-link" data-route="/saved-recipes">My Collection</a></li>
            <li><a href="#" class="nav-link" data-route="/recipes/shared">Shared Recipes</a></li>
            <li><a href="#" class="nav-link" data-route="/recipes/new">Add Recipe</a></li>
            <li class="dropdown">
              <button class="nav-button dropdown-toggle">${user.name} ▼</button>
              <div class="dropdown-menu">
                <a href="#" class="dropdown-item" data-route="/profile">Profile</a>
                <a href="#" class="dropdown-item" id="logout-btn">Logout</a>
              </div>
            </li>
          </ul>
        `

        // Add event listeners to nav links
        document.querySelectorAll(".nav-link, .dropdown-item").forEach((link) => {
          if (link.id !== "logout-btn") {
            link.addEventListener("click", (e) => {
              e.preventDefault()
              navigateTo(link.getAttribute("data-route"))
            })

            // Add active class to current route
            if (link.getAttribute("data-route") === window.location.pathname) {
              link.classList.add("active")
            }
          }
        })

        // Add event listener to logout button
        document.getElementById("logout-btn").addEventListener("click", (e) => {
          e.preventDefault()

          apiRequest("/auth/logout", "POST")
            .then(() => {
              showToast("Logged out successfully", "success")
              navigateTo("/")
            })
            .catch((error) => {
              showToast(error.message, "error")
            })
        })

        // Add dropdown toggle functionality
        const dropdownToggle = document.querySelector(".dropdown-toggle")
        if (dropdownToggle) {
          dropdownToggle.addEventListener("click", () => {
            document.querySelector(".dropdown-menu").classList.toggle("show")
          })

          // Close dropdown when clicking outside
          document.addEventListener("click", (e) => {
            if (!e.target.matches(".dropdown-toggle") && !e.target.closest(".dropdown-menu")) {
              document.querySelector(".dropdown-menu").classList.remove("show")
            }
          })
        }
      })
      .catch(() => {
        // If error (not logged in), show login/register links
        const nav = document.getElementById("main-nav")
        nav.innerHTML = `
          <ul>
            <li><a href="#" class="nav-link" data-route="/">Home</a></li>
            <li><a href="#" class="nav-link" data-route="/recipes">Recipes</a></li>
            <li><a href="#" class="nav-link" data-route="/login">Login</a></li>
            <li><a href="#" class="nav-link" data-route="/register">Register</a></li>
          </ul>
        `

        // Add event listeners to nav links
        document.querySelectorAll(".nav-link").forEach((link) => {
          link.addEventListener("click", (e) => {
            e.preventDefault()
            navigateTo(link.getAttribute("data-route"))
          })

          // Add active class to current route
          if (link.getAttribute("data-route") === window.location.pathname) {
            link.classList.add("active")
          }
        })
      })
  }

  function displayRecipes(recipes) {
    const recipeList = document.getElementById("recipe-list")
    recipeList.innerHTML = ""

    if (recipes.length === 0) {
      recipeList.innerHTML = `
        <div class="empty-state">
          <p>No recipes match your search. Try adjusting your filters.</p>
        </div>
      `
      return
    }

    recipes.forEach((recipe) => {
      recipeList.appendChild(createRecipeCard(recipe))
    })
  }

  function createRecipeCard(recipe) {
    const card = document.createElement("div")
    card.className = "recipe-card"

    card.innerHTML = `
      <div class="recipe-card-image">
        <img src="${recipe.imageUrl || "https://via.placeholder.com/400x300?text=No+Image"}" alt="${recipe.title}">
      </div>
      <div class="recipe-card-content">
        <h3 class="recipe-card-title">${recipe.title}</h3>
        <p class="recipe-card-description">${recipe.description}</p>
        <div class="recipe-card-meta">
          <span>Prep: ${recipe.prepTime} min</span>
          <span>Cook: ${recipe.cookTime} min</span>
        </div>
        <div class="recipe-card-tags">
          ${recipe.tags.map((tag) => `<span class="recipe-tag">${tag}</span>`).join("")}
        </div>
        <div class="recipe-card-actions">
          <button class="btn btn-primary view-recipe" data-id="${recipe.id}">View Recipe</button>
          <button class="btn btn-outline toggle-save" data-id="${recipe.id}">Save</button>
        </div>
      </div>
    `

    // Add event listeners
    card.querySelector(".view-recipe").addEventListener("click", () => {
      navigateTo("/recipes/view", { id: recipe.id })
    })

    const saveButton = card.querySelector(".toggle-save")
    saveButton.addEventListener("click", () => {
      const recipeId = saveButton.getAttribute("data-id")

      // Check if recipe is saved
      apiRequest(`/recipes/${recipeId}/is-saved`)
        .then((data) => {
          const isSaved = data.isSaved

          if (isSaved) {
            apiRequest(`/recipes/${recipeId}/save`, "DELETE")
              .then(() => {
                saveButton.textContent = "Save"
                showToast("Recipe removed from your collection", "success")

                // If we're on the saved recipes page, remove the card
                if (window.location.pathname === "/saved-recipes") {
                  card.remove()

                  // Check if we need to show the empty state
                  const savedRecipesList = document.getElementById("saved-recipe-list")
                  if (savedRecipesList && savedRecipesList.children.length === 0) {
                    savedRecipesList.classList.add("hidden")
                    document.getElementById("empty-saved-recipes").classList.remove("hidden")
                  }
                }
              })
              .catch((error) => {
                showToast(error.message, "error")
              })
          } else {
            apiRequest(`/recipes/${recipeId}/save`, "POST")
              .then(() => {
                saveButton.textContent = "Unsave"
                showToast("Recipe saved to your collection", "success")
              })
              .catch((error) => {
                showToast(error.message, "error")
              })
          }
        })
        .catch((error) => {
          showToast(error.message, "error")
        })
    })

    return card
  }

  function createIngredientRow(value = "") {
    const row = document.createElement("div")
    row.className = "ingredient-row"

    row.innerHTML = `
      <input type="text" class="ingredient-input" placeholder="e.g., 1 cup flour" value="${value}" required>
      <button type="button" class="remove-btn">×</button>
    `

    row.querySelector(".remove-btn").addEventListener("click", () => {
      const container = document.getElementById("ingredients-container")
      if (container.children.length > 1) {
        row.remove()
      }
    })

    return row
  }

  function createInstructionRow(value = "", number = 1) {
    const row = document.createElement("div")
    row.className = "instruction-row"

    row.innerHTML = `
      <span class="step-number">${number}</span>
      <textarea class="instruction-input" placeholder="Describe this step..." rows="2" required>${value}</textarea>
      <button type="button" class="remove-btn">×</button>
    `

    row.querySelector(".remove-btn").addEventListener("click", () => {
      const container = document.getElementById("instructions-container")
      if (container.children.length > 1) {
        row.remove()

        // Update step numbers
        Array.from(container.children).forEach((row, index) => {
          row.querySelector(".step-number").textContent = index + 1
        })
      }
    })

    return row
  }

  function setupRecipeForm() {
    // Add ingredient row
    document.getElementById("add-ingredient-btn").addEventListener("click", () => {
      const container = document.getElementById("ingredients-container")
      container.appendChild(createIngredientRow())
    })

    // Add instruction row
    document.getElementById("add-instruction-btn").addEventListener("click", () => {
      const container = document.getElementById("instructions-container")
      const newIndex = container.children.length + 1
      container.appendChild(createInstructionRow("", newIndex))
    })

    // Setup remove buttons for existing rows
    document.querySelectorAll(".remove-btn").forEach((button) => {
      button.addEventListener("click", () => {
        const row = button.closest(".ingredient-row, .instruction-row")
        const container = row.parentElement

        if (container.children.length > 1) {
          row.remove()

          // Update step numbers for instructions
          if (row.classList.contains("instruction-row")) {
            Array.from(container.children).forEach((row, index) => {
              row.querySelector(".step-number").textContent = index + 1
            })
          }
        }
      })
    })
  }

  function setupFilters(recipes) {
    const filterContainer = document.getElementById("filter-tags")

    // Get all unique tags from recipes
    const allTags = new Set()
    recipes.forEach((recipe) => {
      recipe.tags.forEach((tag) => allTags.add(tag))
    })

    // Create filter tags
    Array.from(allTags)
      .sort()
      .forEach((tag) => {
        const tagElement = document.createElement("div")
        tagElement.className = "filter-tag"
        tagElement.textContent = tag
        tagElement.setAttribute("data-tag", tag)

        tagElement.addEventListener("click", () => {
          tagElement.classList.toggle("active")
          handleRecipeSearch()
        })

        filterContainer.appendChild(tagElement)
      })
  }

  function handleRecipeSearch() {
    const searchTerm = document.getElementById("search-input").value
    const activeFilters = Array.from(document.querySelectorAll(".filter-tag.active")).map((tag) =>
      tag.getAttribute("data-tag"),
    )

    let url = "/recipes/search?"
    if (searchTerm) {
      url += `query=${encodeURIComponent(searchTerm)}&`
    }
    if (activeFilters.length > 0) {
      url += `tags=${encodeURIComponent(activeFilters.join(","))}`
    }

    apiRequest(url)
      .then((data) => {
        displayRecipes(data.recipes)
      })
      .catch((error) => {
        showToast(error.message, "error")
      })
  }

  function getRecipeFormData() {
    const title = document.getElementById("recipe-title").value
    const description = document.getElementById("recipe-description").value
    const prepTime = Number.parseInt(document.getElementById("recipe-prep-time").value)
    const cookTime = Number.parseInt(document.getElementById("recipe-cook-time").value)
    const servings = Number.parseInt(document.getElementById("recipe-servings").value)
    const imageUrl = document.getElementById("recipe-image-url").value

    // Get tags
    const tagsInput = document.getElementById("recipe-tags").value
    const tags = tagsInput
      .split(",")
      .map((tag) => tag.trim())
      .filter((tag) => tag !== "")

    // Get ingredients
    const ingredientInputs = document.querySelectorAll(".ingredient-input")
    const ingredients = Array.from(ingredientInputs)
      .map((input) => input.value.trim())
      .filter((ingredient) => ingredient !== "")

    // Get instructions
    const instructionInputs = document.querySelectorAll(".instruction-input")
    const instructions = Array.from(instructionInputs)
      .map((input) => input.value.trim())
      .filter((instruction) => instruction !== "")

    return {
      title,
      description,
      ingredients,
      instructions,
      prepTime,
      cookTime,
      servings,
      imageUrl,
      tags,
    }
  }

  // Initialize App
  function init() {
    // Handle browser navigation events
    window.addEventListener("popstate", handleRouteChange)

    // Initial route handling
    handleRouteChange()

    // Expose functions to global scope
    window.recipeBox = {
      showToast,
      closeToast,
      showLoading,
      hideLoading,
      apiRequest,
      navigateTo,
    }
  }
})
