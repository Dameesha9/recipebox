// Auth Controller
const User = require("../models/user.js")
const emailService = require("../services/email.js")
const crypto = require("crypto")

// Store reset tokens (in a real app, these would be in a database with expiry)
const resetTokens = {}

class AuthController {
  static async register(req, res) {
    try {
      const { name, email, password } = req.body

      // Validate password
      if (!this.validatePassword(password)) {
        return res.status(400).json({
          success: false,
          message: "Password must be at least 8 characters with at least one special character",
        })
      }

      const user = await User.create({ name, email, password })

      // Set session
      req.session.user = user

      // Send welcome email
      await emailService.sendWelcomeEmail(user.email, user.name)

      return res.status(201).json({ success: true, user })
    } catch (error) {
      return res.status(400).json({ success: false, message: error.message })
    }
  }

  static async login(req, res) {
    try {
      const { email, password } = req.body

      // Validate credentials
      const isValid = await User.validatePassword(email, password)
      if (!isValid) {
        return res.status(401).json({ success: false, message: "Invalid email or password" })
      }

      // Get user
      const user = await User.getByEmail(email)

      // Remove password from response
      const { password: _, ...userWithoutPassword } = user

      // Set session
      req.session.user = userWithoutPassword

      return res.status(200).json({ success: true, user: userWithoutPassword })
    } catch (error) {
      return res.status(400).json({ success: false, message: error.message })
    }
  }

  static async logout(req, res) {
    req.session.destroy()
    return res.status(200).json({ success: true })
  }

  static async forgotPassword(req, res) {
    try {
      const { email } = req.body

      // Check if user exists
      const user = await User.getByEmail(email)
      if (!user) {
        // Don't reveal that the user doesn't exist
        return res.status(200).json({
          success: true,
          message: "If your email is registered, you will receive a password reset link",
        })
      }

      // Generate reset token
      const resetToken = crypto.randomBytes(20).toString("hex")

      // Store token with expiry (24 hours)
      resetTokens[resetToken] = {
        userId: user.id,
        expires: Date.now() + 24 * 60 * 60 * 1000,
      }

      // Send password reset email
      await emailService.sendPasswordResetEmail(email, user.name, resetToken)

      return res.status(200).json({
        success: true,
        message: "If your email is registered, you will receive a password reset link",
      })
    } catch (error) {
      return res.status(400).json({ success: false, message: error.message })
    }
  }

  static async resetPassword(req, res) {
    try {
      const { token, password } = req.body

      // Check if token exists and is valid
      if (!resetTokens[token] || resetTokens[token].expires < Date.now()) {
        return res.status(400).json({ success: false, message: "Invalid or expired token" })
      }

      // Validate password
      if (!this.validatePassword(password)) {
        return res.status(400).json({
          success: false,
          message: "Password must be at least 8 characters with at least one special character",
        })
      }

      // Update user password
      const userId = resetTokens[token].userId
      await User.update(userId, { password })

      // Remove used token
      delete resetTokens[token]

      return res.status(200).json({ success: true, message: "Password reset successful" })
    } catch (error) {
      return res.status(400).json({ success: false, message: error.message })
    }
  }

  static validatePassword(password) {
    // At least 8 characters with at least one special character
    const specialChars = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]+/
    return password.length >= 8 && specialChars.test(password)
  }
}

module.exports = AuthController
