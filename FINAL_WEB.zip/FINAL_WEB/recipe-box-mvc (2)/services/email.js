// Email service using Nodemailer
const nodemailer = require("nodemailer")
const fs = require("fs")
const path = require("path")

class EmailService {
  constructor() {
    this.transporter = nodemailer.createTransport({
      host: process.env.EMAIL_HOST || "smtp.gmail.com",
      port: process.env.EMAIL_PORT || 587,
      secure: process.env.EMAIL_SECURE === "true",
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
      },
    })
  }

  // Load HTML template and replace placeholders
  async loadTemplate(templateName, replacements) {
    const filePath = path.join(__dirname, "..", "views", "email-templates", `${templateName}.html`)
    let content = fs.readFileSync(filePath, "utf8")

    // Replace all placeholders
    Object.keys(replacements).forEach((key) => {
      const regex = new RegExp(`{{${key}}}`, "g")
      content = content.replace(regex, replacements[key])
    })

    return content
  }

  // Send email
  async sendEmail(to, subject, html) {
    try {
      const mailOptions = {
        from: `"RecipeBox" <${process.env.EMAIL_USER}>`,
        to,
        subject,
        html,
      }

      const info = await this.transporter.sendMail(mailOptions)
      console.log("Email sent:", info.messageId)
      return info
    } catch (error) {
      console.error("Error sending email:", error)
      throw error
    }
  }

  // Send welcome email
  async sendWelcomeEmail(email, name) {
    const html = await this.loadTemplate("welcome", { name })
    const subject = "Welcome to RecipeBox!"
    return this.sendEmail(email, subject, html)
  }

  // Send password reset email
  async sendPasswordResetEmail(email, name, resetToken) {
    const resetUrl = `${process.env.APP_URL}/reset-password?token=${resetToken}`
    const html = await this.loadTemplate("password-reset", { name, resetUrl })
    const subject = "Reset Your RecipeBox Password"
    return this.sendEmail(email, subject, html)
  }

  // Send notification when a recipe is created
  async sendRecipeCreationEmail(email, name, recipeTitle) {
    const html = await this.loadTemplate("recipe-created", { name, recipeTitle })
    const subject = "Your New Recipe on RecipeBox"
    return this.sendEmail(email, subject, html)
  }

  // Send notification when someone saves a recipe
  async sendRecipeSavedEmail(creatorEmail, creatorName, recipeTitle, saverName) {
    const html = await this.loadTemplate("recipe-saved", { creatorName, recipeTitle, saverName })
    const subject = "Someone Saved Your Recipe on RecipeBox"
    return this.sendEmail(creatorEmail, subject, html)
  }

  // Share a recipe with a friend
  async shareRecipeWithFriend(recipientEmail, senderName, recipeTitle, recipeUrl, personalMessage = "") {
    const html = await this.loadTemplate("share-recipe", {
      senderName,
      recipeTitle,
      recipeUrl,
      personalMessage: personalMessage ? `<p>Message from ${senderName}: "${personalMessage}"</p>` : "",
    })
    const subject = `${senderName} shared a recipe with you: ${recipeTitle}`
    return this.sendEmail(recipientEmail, subject, html)
  }
}

module.exports = new EmailService()
