// Main server file
const express = require("express")
const path = require("path")
const bodyParser = require("body-parser")
const session = require("express-session")

// Initialize Express app
const app = express()
const PORT = process.env.PORT || 3000

// Middleware
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: true }))
app.use(express.static(path.join(__dirname, "public")))
app.use(
  session({
    secret: process.env.SESSION_SECRET || "recipe-box-secret",
    resave: false,
    saveUninitialized: true,
    cookie: { secure: process.env.NODE_ENV === "production" },
  }),
)

// Set view engine to use HTML files
app.engine("html", require("ejs").renderFile)
app.set("view engine", "html")
app.set("views", path.join(__dirname, "views"))

// Routes
const authRoutes = require("./routes/auth.js")
const recipeRoutes = require("./routes/recipe.js")
const userRoutes = require("./routes/user.js")

app.use("/auth", authRoutes)
app.use("/recipes", recipeRoutes)
app.use("/users", userRoutes)

// Home route
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "views", "index.html"))
})

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
})
