// Client-side script for handling recipe details
document.addEventListener("DOMContentLoaded", async () => {
  // Get recipe ID from URL
  const urlParams = new URLSearchParams(window.location.search)
  const recipeId = urlParams.get("id")

  if (!recipeId) return

  try {
    // Fetch recipe details
    const { recipe } = await window.recipeBox.apiRequest(`/recipes/${recipeId}`)

    // Populate recipe details
    document.getElementById("recipe-title").textContent = recipe.title
    document.getElementById("recipe-description").textContent = recipe.description
    document.getElementById("recipe-prep-time").textContent = `Prep: ${recipe.prepTime} min`
    document.getElementById("recipe-cook-time").textContent = `Cook: ${recipe.cookTime} min`
    document.getElementById("recipe-servings").textContent = `Serves: ${recipe.servings}`

    const recipeImage = document.getElementById("recipe-image")
    if (recipeImage) {
      recipeImage.src = recipe.imageUrl || "/images/placeholder-recipe.jpg"
      recipeImage.alt = recipe.title
    }

    // Add ingredients
    const ingredientsList = document.getElementById("recipe-ingredients")
    if (ingredientsList) {
      recipe.ingredients.forEach((ingredient) => {
        const li = document.createElement("li")
        li.textContent = ingredient
        ingredientsList.appendChild(li)
      })
    }

    // Add instructions
    const instructionsList = document.getElementById("recipe-instructions")
    if (instructionsList) {
      recipe.instructions.forEach((instruction, index) => {
        const li = document.createElement("li")
        li.textContent = instruction
        instructionsList.appendChild(li)
      })
    }

    // Add tags
    const tagsContainer = document.getElementById("recipe-tags")
    if (tagsContainer) {
      recipe.tags.forEach((tag) => {
        const tagElement = document.createElement("span")
        tagElement.className = "recipe-tag"
        tagElement.textContent = tag
        tagsContainer.appendChild(tagElement)
      })
    }

    // Check if recipe is saved
    const { isSaved } = await window.recipeBox.apiRequest(`/recipes/${recipeId}/is-saved`)
    const saveButton = document.getElementById("save-recipe-btn")
    if (saveButton) {
      saveButton.textContent = isSaved ? "Unsave Recipe" : "Save Recipe"
      saveButton.setAttribute("data-saved", isSaved)
    }

    // Get share info
    try {
      const { isShared, shareCount } = await window.recipeBox.apiRequest(`/recipes/${recipeId}/share-info`)

      if (isShared && shareCount > 0) {
        const shareInfo = document.createElement("div")
        shareInfo.className = "share-info"
        shareInfo.innerHTML = `<span>Shared ${shareCount} time${shareCount !== 1 ? "s" : ""}</span>`
        document.querySelector(".recipe-actions").appendChild(shareInfo)
      }
    } catch (error) {
      console.error("Error fetching share info:", error)
    }
  } catch (error) {
    window.recipeBox.showToast("Error loading recipe", "error")
    console.error("Error:", error)
  }

  // Handle save/unsave button
  const saveButton = document.getElementById("save-recipe-btn")
  if (saveButton) {
    saveButton.addEventListener("click", async () => {
      const isSaved = saveButton.getAttribute("data-saved") === "true"

      try {
        if (isSaved) {
          await window.recipeBox.apiRequest(`/recipes/${recipeId}/save`, "DELETE")
          saveButton.textContent = "Save Recipe"
          saveButton.setAttribute("data-saved", "false")
          window.recipeBox.showToast("Recipe removed from your collection", "success")
        } else {
          await window.recipeBox.apiRequest(`/recipes/${recipeId}/save`, "POST")
          saveButton.textContent = "Unsave Recipe"
          saveButton.setAttribute("data-saved", "true")
          window.recipeBox.showToast("Recipe saved to your collection", "success")
        }
      } catch (error) {
        window.recipeBox.showToast("Error updating recipe", "error")
      }
    })
  }

  // Handle delete button
  const deleteButton = document.getElementById("delete-recipe-btn")
  if (deleteButton) {
    deleteButton.addEventListener("click", async () => {
      if (confirm("Are you sure you want to delete this recipe?")) {
        try {
          await window.recipeBox.apiRequest(`/recipes/${recipeId}`, "DELETE")
          window.recipeBox.showToast("Recipe deleted successfully", "success")
          window.location.href = "/recipes"
        } catch (error) {
          window.recipeBox.showToast("Error deleting recipe", "error")
        }
      }
    })
  }

  // Handle share button
  const shareButton = document.getElementById("share-recipe-btn")
  if (shareButton) {
    shareButton.setAttribute("data-id", recipeId)
  }
})
