const fs = require("fs")
const path = require("path")
const bcrypt = require("bcrypt")

const dataPath = path.join(__dirname, "../data/users.json")

// Ensure data directory exists
const dataDir = path.join(__dirname, "../data")
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir)
}

// Initialize users file if it doesn't exist
if (!fs.existsSync(dataPath)) {
  fs.writeFileSync(dataPath, JSON.stringify([]))
}

class User {
  static async getAll() {
    try {
      const data = fs.readFileSync(dataPath, "utf8")
      return JSON.parse(data)
    } catch (error) {
      console.error("Error reading users:", error)
      return []
    }
  }

  static async getById(id) {
    const users = await this.getAll()
    return users.find((user) => user.id === id)
  }

  static async getByEmail(email) {
    const users = await this.getAll()
    return users.find((user) => user.email === email)
  }

  static async create(userData) {
    try {
      const users = await this.getAll()

      // Check if email already exists
      if (users.some((user) => user.email === userData.email)) {
        throw new Error("Email already in use")
      }

      // Hash password
      const salt = await bcrypt.genSalt(10)
      const hashedPassword = await bcrypt.hash(userData.password, salt)

      const newUser = {
        id: Date.now().toString(),
        name: userData.name,
        email: userData.email,
        password: hashedPassword,
        createdAt: new Date().toISOString(),
      }

      users.push(newUser)
      fs.writeFileSync(dataPath, JSON.stringify(users, null, 2))

      // Return user without password
      const { password, ...userWithoutPassword } = newUser
      return userWithoutPassword
    } catch (error) {
      console.error("Error creating user:", error)
      throw error
    }
  }

  static async update(id, userData) {
    try {
      const users = await this.getAll()
      const index = users.findIndex((user) => user.id === id)

      if (index === -1) {
        throw new Error("User not found")
      }

      // Update user data
      users[index] = { ...users[index], ...userData }

      // If password is being updated, hash it
      if (userData.password) {
        const salt = await bcrypt.genSalt(10)
        users[index].password = await bcrypt.hash(userData.password, salt)
      }

      fs.writeFileSync(dataPath, JSON.stringify(users, null, 2))

      // Return user without password
      const { password, ...userWithoutPassword } = users[index]
      return userWithoutPassword
    } catch (error) {
      console.error("Error updating user:", error)
      throw error
    }
  }

  static async delete(id) {
    try {
      const users = await this.getAll()
      const filteredUsers = users.filter((user) => user.id !== id)

      fs.writeFileSync(dataPath, JSON.stringify(filteredUsers, null, 2))
      return true
    } catch (error) {
      console.error("Error deleting user:", error)
      throw error
    }
  }

  static async validatePassword(email, password) {
    try {
      const user = await this.getByEmail(email)

      if (!user) {
        return false
      }

      return await bcrypt.compare(password, user.password)
    } catch (error) {
      console.error("Error validating password:", error)
      throw error
    }
  }
}

module.exports = User
