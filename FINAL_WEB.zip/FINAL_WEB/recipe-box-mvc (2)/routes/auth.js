// Auth Routes
const express = require("express")
const AuthController = require("../controllers/auth.js")

const router = express.Router()

// Register
router.post("/register", AuthController.register)

// Login
router.post("/login", AuthController.login)

// Logout
router.post("/logout", AuthController.logout)

// Forgot password
router.post("/forgot-password", AuthController.forgotPassword)

// Reset password
router.post("/reset-password", AuthController.resetPassword)

module.exports = router
