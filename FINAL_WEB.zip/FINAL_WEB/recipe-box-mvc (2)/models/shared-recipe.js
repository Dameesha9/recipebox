// Shared Recipe model
const fs = require("fs")
const path = require("path")

const dataPath = path.join(__dirname, "..", "data", "shared-recipes.json")

// Ensure data directory exists
const dataDir = path.join(__dirname, "..", "data")
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir)
}

// Initialize shared recipes file if it doesn't exist
if (!fs.existsSync(dataPath)) {
  fs.writeFileSync(dataPath, JSON.stringify({}))
}

class SharedRecipe {
  static async getAll() {
    try {
      const data = fs.readFileSync(dataPath, "utf8")
      return JSON.parse(data)
    } catch (error) {
      console.error("Error reading shared recipes:", error)
      return {}
    }
  }

  static async getByUser(userId) {
    const sharedRecipes = await this.getAll()
    return sharedRecipes[userId] || []
  }

  static async share(userId, recipeId, recipientEmail) {
    try {
      const sharedRecipes = await this.getAll()

      if (!sharedRecipes[userId]) {
        sharedRecipes[userId] = []
      }

      const shareRecord = {
        recipeId,
        recipientEmail,
        sharedAt: new Date().toISOString(),
      }

      sharedRecipes[userId].push(shareRecord)
      fs.writeFileSync(dataPath, JSON.stringify(sharedRecipes, null, 2))

      return shareRecord
    } catch (error) {
      console.error("Error sharing recipe:", error)
      throw error
    }
  }

  static async getShareCount(userId, recipeId) {
    const sharedRecipes = await this.getByUser(userId)
    return sharedRecipes.filter((share) => share.recipeId === recipeId).length
  }

  static async isShared(userId, recipeId) {
    const sharedRecipes = await this.getByUser(userId)
    return sharedRecipes.some((share) => share.recipeId === recipeId)
  }
}

module.exports = SharedRecipe
