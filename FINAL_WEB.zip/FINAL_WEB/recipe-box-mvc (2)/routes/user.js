// User Routes
const express = require("express")
const UserController = require("../controllers/user.js")

const router = express.Router()

// Get user profile
router.get("/profile", UserController.getProfile)

// Update user profile
router.put("/profile", UserController.updateProfile)

// Change password
router.post("/change-password", UserController.changePassword)

// Get user recipes
router.get("/recipes", UserController.getUserRecipes)

module.exports = router
