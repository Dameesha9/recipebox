// Recipe Controller
const Recipe = require("../models/recipe.js")
const SavedRecipe = require("../models/saved-recipe.js")
const SharedRecipe = require("../models/shared-recipe.js")
const User = require("../models/user.js")
const emailService = require("../services/email.js")

class RecipeController {
  static async getAll(req, res) {
    try {
      const recipes = await Recipe.getAll()
      return res.status(200).json({ success: true, recipes })
    } catch (error) {
      return res.status(400).json({ success: false, message: error.message })
    }
  }

  static async getById(req, res) {
    try {
      const { id } = req.params
      const recipe = await Recipe.getById(id)

      if (!recipe) {
        return res.status(404).json({ success: false, message: "Recipe not found" })
      }

      return res.status(200).json({ success: true, recipe })
    } catch (error) {
      return res.status(400).json({ success: false, message: error.message })
    }
  }

  static async create(req, res) {
    try {
      if (!req.session.user) {
        return res.status(401).json({ success: false, message: "Unauthorized" })
      }

      const recipeData = {
        ...req.body,
        createdBy: req.session.user.id,
      }

      const recipe = await Recipe.create(recipeData)

      // Notify user about new recipe creation
      await emailService.sendRecipeCreationEmail(req.session.user.email, req.session.user.name, recipe.title)

      return res.status(201).json({ success: true, recipe })
    } catch (error) {
      return res.status(400).json({ success: false, message: error.message })
    }
  }

  static async update(req, res) {
    try {
      if (!req.session.user) {
        return res.status(401).json({ success: false, message: "Unauthorized" })
      }

      const { id } = req.params
      const recipe = await Recipe.getById(id)

      if (!recipe) {
        return res.status(404).json({ success: false, message: "Recipe not found" })
      }

      // Check if user is the creator
      if (recipe.createdBy !== req.session.user.id) {
        return res.status(403).json({ success: false, message: "Forbidden" })
      }

      const updatedRecipe = await Recipe.update(id, req.body)
      return res.status(200).json({ success: true, recipe: updatedRecipe })
    } catch (error) {
      return res.status(400).json({ success: false, message: error.message })
    }
  }

  static async delete(req, res) {
    try {
      if (!req.session.user) {
        return res.status(401).json({ success: false, message: "Unauthorized" })
      }

      const { id } = req.params
      const recipe = await Recipe.getById(id)

      if (!recipe) {
        return res.status(404).json({ success: false, message: "Recipe not found" })
      }

      // Check if user is the creator
      if (recipe.createdBy !== req.session.user.id) {
        return res.status(403).json({ success: false, message: "Forbidden" })
      }

      await Recipe.delete(id)
      return res.status(200).json({ success: true })
    } catch (error) {
      return res.status(400).json({ success: false, message: error.message })
    }
  }

  static async search(req, res) {
    try {
      const { query, tags } = req.query
      const tagsArray = tags ? tags.split(",") : []

      const recipes = await Recipe.search(query, tagsArray)
      return res.status(200).json({ success: true, recipes })
    } catch (error) {
      return res.status(400).json({ success: false, message: error.message })
    }
  }

  static async saveRecipe(req, res) {
    try {
      if (!req.session.user) {
        return res.status(401).json({ success: false, message: "Unauthorized" })
      }

      const { id } = req.params
      const recipe = await Recipe.getById(id)

      if (!recipe) {
        return res.status(404).json({ success: false, message: "Recipe not found" })
      }

      await SavedRecipe.save(req.session.user.id, id)

      // Get recipe creator to notify them
      const creator = await User.getById(recipe.createdBy)
      if (creator && creator.id !== req.session.user.id) {
        await emailService.sendRecipeSavedEmail(creator.email, creator.name, recipe.title, req.session.user.name)
      }

      return res.status(200).json({ success: true })
    } catch (error) {
      return res.status(400).json({ success: false, message: error.message })
    }
  }

  static async unsaveRecipe(req, res) {
    try {
      if (!req.session.user) {
        return res.status(401).json({ success: false, message: "Unauthorized" })
      }

      const { id } = req.params
      await SavedRecipe.remove(req.session.user.id, id)

      return res.status(200).json({ success: true })
    } catch (error) {
      return res.status(400).json({ success: false, message: error.message })
    }
  }

  static async getSavedRecipes(req, res) {
    try {
      if (!req.session.user) {
        return res.status(401).json({ success: false, message: "Unauthorized" })
      }

      const savedIds = await SavedRecipe.getByUser(req.session.user.id)
      const allRecipes = await Recipe.getAll()

      const savedRecipes = allRecipes.filter((recipe) => savedIds.includes(recipe.id))

      return res.status(200).json({ success: true, recipes: savedRecipes })
    } catch (error) {
      return res.status(400).json({ success: false, message: error.message })
    }
  }

  static async isSaved(req, res) {
    try {
      if (!req.session.user) {
        return res.status(401).json({ success: false, message: "Unauthorized" })
      }

      const { id } = req.params
      const isSaved = await SavedRecipe.isSaved(req.session.user.id, id)

      return res.status(200).json({ success: true, isSaved })
    } catch (error) {
      return res.status(400).json({ success: false, message: error.message })
    }
  }

  static async shareRecipe(req, res) {
    try {
      if (!req.session.user) {
        return res.status(401).json({ success: false, message: "Unauthorized" })
      }

      const { id } = req.params
      const { recipientEmail, message } = req.body

      const recipe = await Recipe.getById(id)
      if (!recipe) {
        return res.status(404).json({ success: false, message: "Recipe not found" })
      }

      // Create share record
      await SharedRecipe.share(req.session.user.id, id, recipientEmail)

      // Generate recipe URL
      const recipeUrl = `${process.env.APP_URL}/recipes/${id}`

      // Send email
      await emailService.shareRecipeWithFriend(recipientEmail, req.session.user.name, recipe.title, recipeUrl, message)

      return res.status(200).json({ success: true })
    } catch (error) {
      return res.status(400).json({ success: false, message: error.message })
    }
  }

  static async getSharedRecipes(req, res) {
    try {
      if (!req.session.user) {
        return res.status(401).json({ success: false, message: "Unauthorized" })
      }

      const sharedRecords = await SharedRecipe.getByUser(req.session.user.id)
      const allRecipes = await Recipe.getAll()

      // Get unique recipe IDs from share records
      const sharedRecipeIds = [...new Set(sharedRecords.map((record) => record.recipeId))]

      // Get recipes and add share count
      const sharedRecipes = allRecipes
        .filter((recipe) => sharedRecipeIds.includes(recipe.id))
        .map((recipe) => {
          const shareCount = sharedRecords.filter((record) => record.recipeId === recipe.id).length
          return { ...recipe, shareCount }
        })

      return res.status(200).json({ success: true, recipes: sharedRecipes })
    } catch (error) {
      return res.status(400).json({ success: false, message: error.message })
    }
  }

  static async getShareInfo(req, res) {
    try {
      if (!req.session.user) {
        return res.status(401).json({ success: false, message: "Unauthorized" })
      }

      const { id } = req.params
      const isShared = await SharedRecipe.isShared(req.session.user.id, id)
      const shareCount = await SharedRecipe.getShareCount(req.session.user.id, id)

      return res.status(200).json({ success: true, isShared, shareCount })
    } catch (error) {
      return res.status(400).json({ success: false, message: error.message })
    }
  }
}

module.exports = RecipeController
