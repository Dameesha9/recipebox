// Auth Middleware
function isAuthenticated(req, res, next) {
  if (req.session.user) {
    return next()
  }

  // For API requests
  if (req.xhr || req.headers.accept.indexOf("json") > -1) {
    return res.status(401).json({ success: false, message: "Unauthorized" })
  }

  // For page requests
  return res.redirect("/login")
}

module.exports = {
  isAuthenticated,
}
