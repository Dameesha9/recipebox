const User = require("../models/user.model")
const Recipe = require("../models/recipe.model")
const emailService = require("../services/email.service")
const AuthController = require("./auth.controller") // Import AuthController

class UserController {
  static async getProfile(req, res) {
    try {
      if (!req.session.user) {
        return res.status(401).json({ success: false, message: "Unauthorized" })
      }

      const user = await User.getById(req.session.user.id)

      if (!user) {
        return res.status(404).json({ success: false, message: "User not found" })
      }

      // Remove password from response
      const { password, ...userWithoutPassword } = user

      return res.status(200).json({ success: true, user: userWithoutPassword })
    } catch (error) {
      return res.status(400).json({ success: false, message: error.message })
    }
  }

  static async updateProfile(req, res) {
    try {
      if (!req.session.user) {
        return res.status(401).json({ success: false, message: "Unauthorized" })
      }

      const { name, email } = req.body

      // Check if email is being changed and if it's already in use
      if (email && email !== req.session.user.email) {
        const existingUser = await User.getByEmail(email)
        if (existingUser) {
          return res.status(400).json({ success: false, message: "Email already in use" })
        }
      }

      const updatedUser = await User.update(req.session.user.id, { name, email })

      // Update session
      req.session.user = updatedUser

      return res.status(200).json({ success: true, user: updatedUser })
    } catch (error) {
      return res.status(400).json({ success: false, message: error.message })
    }
  }

  static async changePassword(req, res) {
    try {
      if (!req.session.user) {
        return res.status(401).json({ success: false, message: "Unauthorized" })
      }

      const { currentPassword, newPassword } = req.body

      // Validate current password
      const isValid = await User.validatePassword(req.session.user.email, currentPassword)
      if (!isValid) {
        return res.status(401).json({ success: false, message: "Current password is incorrect" })
      }

      // Validate new password
      if (!AuthController.validatePassword(newPassword)) {
        return res.status(400).json({
          success: false,
          message: "Password must be at least 8 characters with at least one special character",
        })
      }

      await User.update(req.session.user.id, { password: newPassword })

      // Notify user about password change
      await emailService.sendPasswordChangedEmail(req.session.user.email, req.session.user.name)

      return res.status(200).json({ success: true })
    } catch (error) {
      return res.status(400).json({ success: false, message: error.message })
    }
  }

  static async getUserRecipes(req, res) {
    try {
      if (!req.session.user) {
        return res.status(401).json({ success: false, message: "Unauthorized" })
      }

      const recipes = await Recipe.getByUser(req.session.user.id)
      return res.status(200).json({ success: true, recipes })
    } catch (error) {
      return res.status(400).json({ success: false, message: error.message })
    }
  }
}

module.exports = UserController
